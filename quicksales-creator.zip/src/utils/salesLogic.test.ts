import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateDiscount,
  formatCurrencyBRL,
  calculateRoutineProgress,
  generatePixPayload,
  PRODUCTS,
} from './salesLogic.ts';

test('PRODUCTS definition includes ebook and app at specified prices', () => {
  assert.equal(PRODUCTS.ebook.price, 9.90);
  assert.equal(PRODUCTS.app.price, 19.90);
  assert.equal(PRODUCTS.bundle.price, 24.90);
});

test('calculateDiscount returns correct discount percentages', () => {
  assert.equal(calculateDiscount(9.90, 47.00), 79);
  assert.equal(calculateDiscount(19.90, 97.00), 79);
  assert.equal(calculateDiscount(100, 100), 0);
  assert.equal(calculateDiscount(150, 100), 0);
});

test('calculateRoutineProgress handles various steps scenarios', () => {
  assert.equal(calculateRoutineProgress([]), 0);
  assert.equal(calculateRoutineProgress([false, false, false, false]), 0);
  assert.equal(calculateRoutineProgress([true, false, false, false]), 25);
  assert.equal(calculateRoutineProgress([true, true, false, false]), 50);
  assert.equal(calculateRoutineProgress([true, true, true, false]), 75);
  assert.equal(calculateRoutineProgress([true, true, true, true]), 100);
});

test('generatePixPayload includes required identifiers', () => {
  const pix = generatePixPayload('ebook', 9.90);
  assert.ok(pix.includes('BR.GOV.BCB.PIX'));
  assert.ok(pix.includes('PELE SEM ACNE'));
  assert.ok(pix.includes('EBOOK'));
});

test('formatCurrencyBRL formats number properly', () => {
  const formatted = formatCurrencyBRL(9.90);
  assert.ok(formatted.includes('9,90'));
});
