/**
 * Pure business logic for the Skincare Sales Page & App Simulator
 */

export interface ProductItem {
  id: 'ebook' | 'app' | 'bundle';
  name: string;
  tagline: string;
  price: number;
  originalPrice: number;
  badge?: string;
  features: string[];
}

export const PRODUCTS: Record<string, ProductItem> = {
  ebook: {
    id: 'ebook',
    name: 'Guia Prático: Cuidados com a Pele Acne',
    tagline: 'O manual definitivo em PDF com dicas práticas, simples e eficazes.',
    price: 9.90,
    originalPrice: 47.00,
    badge: 'Acesso Imediato',
    features: [
      'Guia Completo Passo a Passo (PDF de alta resolução)',
      'Técnicas de limpeza e equilíbrio sebáceo sem ressecar',
      'Guia de Ativos: Cica, Niacinamida e Ácido Salicílico',
      'Tratamentos caseiros seguros e receitas aprovadas',
      'Rotinas para Acne Grau 1 e Grau 2',
      'Bônus: Lista de produtos acessíveis de farmácia'
    ]
  },
  app: {
    id: 'app',
    name: 'Aplicação: Minha Rotina Skincare',
    tagline: 'Aplicativo web interativo para celular e computador com checklist diário.',
    price: 19.90,
    originalPrice: 97.00,
    badge: 'Mais Vendido',
    features: [
      'Checklist diário de rotina (Manhã e Noite)',
      'Rastreador de progresso semanal e gráfico de consistência',
      'Calendário inteligente de hábitos da pele',
      'Gestor personalizado de produtos que você já tem em casa',
      'Dica do dia recomendada por dermatologistas',
      'Acesso vitalício sem mensalidades ou taxas extras'
    ]
  },
  bundle: {
    id: 'bundle',
    name: 'Combo Completo: E-book + Aplicativo',
    tagline: 'O conhecimento profundo do guia somado ao aplicativo diário no seu bolso.',
    price: 24.90,
    originalPrice: 144.00,
    badge: 'Melhor Custo-Benefício (Economize 83%)',
    features: [
      'Tudo incluso no E-book "Cuidados com a Pele Acne"',
      'Acesso completo vitalício ao Aplicativo "Minha Rotina"',
      'Guia Extra: Cronograma de 30 Dias Pele Radiante',
      'Canal de suporte prioritário para tirar dúvidas',
      'Acesso instantâneo em qualquer celular ou PC'
    ]
  }
};

/**
 * Calculates discount percentage
 */
export function calculateDiscount(price: number, originalPrice: number): number {
  if (originalPrice <= 0 || price >= originalPrice) return 0;
  return Math.round(((originalPrice - price) / originalPrice) * 100);
}

/**
 * Formats Brazilian Real currency (e.g. R$ 9,90)
 */
export function formatCurrencyBRL(amount: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

/**
 * Calculates routine completion percentage given an array of step completion states
 */
export function calculateRoutineProgress(steps: boolean[]): number {
  if (!steps || steps.length === 0) return 0;
  const completedCount = steps.filter(Boolean).length;
  return Math.round((completedCount / steps.length) * 100);
}

/**
 * Generates simulated Pix copy and paste payload
 */
export function generatePixPayload(productId: string, amount: number): string {
  const cleanId = productId.toUpperCase();
  const hexAmount = amount.toFixed(2).replace('.', '');
  return `00020126580014BR.GOV.BCB.PIX0136pix@pelesemacne.com.br520400005303986540${hexAmount}5802BR5915PELE SEM ACNE6009SAO PAULO62070503${cleanId}6304A1B2`;
}
