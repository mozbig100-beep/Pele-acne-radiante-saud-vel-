/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { InteractiveAppDemo } from './components/InteractiveAppDemo';
import { EbookPreview } from './components/EbookPreview';
import { ProductComparison } from './components/ProductComparison';
import { ScienceSection } from './components/ScienceSection';
import { Testimonials } from './components/Testimonials';
import { GuaranteeSection } from './components/GuaranteeSection';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import { StickyMobileBar } from './components/StickyMobileBar';
import { CheckoutModal } from './components/CheckoutModal';
import { FullAppModal } from './components/FullAppModal';

export default function App() {
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [selectedProductId, setSelectedProductId] = useState<'ebook' | 'app' | 'bundle'>('ebook');
  const [isFullAppOpen, setIsFullAppOpen] = useState(false);

  const handleSelectProduct = (productId: 'ebook' | 'app' | 'bundle') => {
    setSelectedProductId(productId);
    setIsCheckoutOpen(true);
  };

  const handleScrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF7F2] text-[#2C2925] font-sans">
      {/* Navigation Header */}
      <Header 
        onSelectProduct={handleSelectProduct}
        onOpenDemo={() => handleScrollToSection('demo-app')}
      />

      {/* Main Content */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero 
          onSelectProduct={handleSelectProduct}
          onScrollToSection={handleScrollToSection}
        />

        {/* Product Comparison & Pricing Table */}
        <ProductComparison 
          onSelectProduct={handleSelectProduct}
        />

        {/* Interactive App Demo (Phone Simulator) */}
        <InteractiveAppDemo 
          onSelectProduct={handleSelectProduct}
        />

        {/* Ebook Chapter Sample & Preview */}
        <EbookPreview 
          onSelectProduct={handleSelectProduct}
        />

        {/* Science Behind Actives (Cica, Niacinamida, Ácido Salicílico) */}
        <ScienceSection />

        {/* Real Customer Testimonials & Results */}
        <Testimonials />

        {/* 7-Day Unconditional Guarantee */}
        <GuaranteeSection 
          onSelectProduct={handleSelectProduct}
        />

        {/* FAQ Accordion */}
        <FaqSection />
      </main>

      {/* Footer */}
      <Footer 
        onSelectProduct={handleSelectProduct}
      />

      {/* Mobile Sticky CTA Bar */}
      <StickyMobileBar 
        onSelectProduct={handleSelectProduct}
      />

      {/* Interactive Checkout Modal */}
      <CheckoutModal 
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        selectedProductId={selectedProductId}
        onChangeProduct={(id) => setSelectedProductId(id)}
        onOpenFullApp={() => setIsFullAppOpen(true)}
      />

      {/* Full Screen Live Skincare Web App Simulator */}
      <FullAppModal 
        isOpen={isFullAppOpen}
        onClose={() => setIsFullAppOpen(false)}
      />
    </div>
  );
}
