import React, { useState, useEffect } from 'react';
import { Sparkles, ShieldCheck, Clock, ArrowRight, Menu, X, Smartphone, BookOpen } from 'lucide-react';

interface HeaderProps {
  onSelectProduct: (productId: 'ebook' | 'app' | 'bundle') => void;
  onOpenDemo: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onSelectProduct, onOpenDemo }) => {
  const [timeLeft, setTimeLeft] = useState({ minutes: 14, seconds: 59 });
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { minutes: prev.minutes - 1, seconds: 59 };
        }
        return { minutes: 15, seconds: 0 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (num: number) => num.toString().padStart(2, '0');

  const scrollTo = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-[#FAF7F2]/95 backdrop-blur-md border-b border-[#E8DFD8]">
      {/* Top Urgency Bar */}
      <div className="bg-[#2D2A26] text-[#FAF7F2] text-xs sm:text-sm py-2 px-4">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 mx-auto sm:mx-0 font-medium">
            <span className="inline-flex items-center justify-center bg-[#C68B70] text-white px-2 py-0.5 rounded text-[11px] font-bold uppercase tracking-wider">
              Oferta Especial
            </span>
            <span>Preços promocionais a partir de apenas <strong>R$ 9,90</strong></span>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-xs font-mono text-[#E4D5CA] mx-auto sm:mx-0">
            <Clock className="w-3.5 h-3.5 text-[#C68B70]" />
            <span>Oferta encerra em:</span>
            <span className="bg-[#3D3934] px-1.5 py-0.5 rounded text-white font-semibold">
              00:{formatTime(timeLeft.minutes)}:{formatTime(timeLeft.seconds)}
            </span>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 sm:h-20 flex items-center justify-between">
        {/* Brand / Logo */}
        <a href="#hero" className="flex items-center gap-2.5 group text-left">
          <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#EAD8CD] flex items-center justify-center text-[#7A4B3A] shadow-xs group-hover:scale-105 transition-transform">
            <Sparkles className="w-5 h-5 text-[#8E513D]" />
          </div>
          <div>
            <span className="block font-serif text-xl sm:text-2xl font-bold tracking-tight text-[#2D2A26] leading-none">
              Pele & Rotina
            </span>
            <span className="block text-[11px] font-medium text-[#7D756D] uppercase tracking-wider">
              Cuidados com a Pele Acne
            </span>
          </div>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-[#574F48]">
          <button 
            onClick={() => scrollTo('produtos')} 
            className="hover:text-[#8E513D] transition-colors cursor-pointer"
          >
            Produtos & Preços
          </button>
          <button 
            onClick={() => scrollTo('demo-app')} 
            className="hover:text-[#8E513D] transition-colors flex items-center gap-1.5 cursor-pointer text-[#8E513D] font-semibold"
          >
            <Smartphone className="w-4 h-4" />
            Testar App
          </button>
          <button 
            onClick={() => scrollTo('ebook-preview')} 
            className="hover:text-[#8E513D] transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <BookOpen className="w-4 h-4" />
            Ver E-book
          </button>
          <button 
            onClick={() => scrollTo('depoimentos')} 
            className="hover:text-[#8E513D] transition-colors cursor-pointer"
          >
            Resultados
          </button>
          <button 
            onClick={() => scrollTo('faq')} 
            className="hover:text-[#8E513D] transition-colors cursor-pointer"
          >
            Dúvidas
          </button>
        </nav>

        {/* Action Button */}
        <div className="hidden sm:flex items-center gap-3">
          <button
            onClick={() => onSelectProduct('bundle')}
            className="bg-[#8E513D] hover:bg-[#794231] text-white px-4 py-2 sm:py-2.5 rounded-full text-xs sm:text-sm font-semibold shadow-sm hover:shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <span>Garantir Acesso</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* Mobile Hamburger */}
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 rounded-lg text-[#574F48] hover:bg-[#EFE7E0] transition-colors cursor-pointer"
          aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#FAF7F2] border-b border-[#E8DFD8] px-4 py-5 shadow-lg space-y-3">
          <button
            onClick={() => scrollTo('produtos')}
            className="block w-full text-left py-2 text-sm font-medium text-[#2D2A26] border-b border-[#F0E8E1]"
          >
            Produtos (E-book R$ 9,90 / App R$ 19,90)
          </button>
          <button
            onClick={() => scrollTo('demo-app')}
            className="flex items-center gap-2 w-full text-left py-2 text-sm font-semibold text-[#8E513D] border-b border-[#F0E8E1]"
          >
            <Smartphone className="w-4 h-4" />
            Demonstração Interativa do Aplicativo
          </button>
          <button
            onClick={() => scrollTo('ebook-preview')}
            className="flex items-center gap-2 w-full text-left py-2 text-sm font-medium text-[#2D2A26] border-b border-[#F0E8E1]"
          >
            <BookOpen className="w-4 h-4" />
            Amostra & Capítulos do E-book
          </button>
          <button
            onClick={() => scrollTo('depoimentos')}
            className="block w-full text-left py-2 text-sm font-medium text-[#2D2A26] border-b border-[#F0E8E1]"
          >
            Depoimentos & Antes e Depois
          </button>
          <button
            onClick={() => scrollTo('garantia')}
            className="block w-full text-left py-2 text-sm font-medium text-[#2D2A26] border-b border-[#F0E8E1]"
          >
            Garantia de 7 Dias
          </button>
          <button
            onClick={() => scrollTo('faq')}
            className="block w-full text-left py-2 text-sm font-medium text-[#2D2A26]"
          >
            Perguntas Frequentes
          </button>

          <div className="pt-2 flex flex-col gap-2">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onSelectProduct('ebook');
              }}
              className="w-full text-center py-2.5 rounded-lg border border-[#8E513D] text-[#8E513D] font-medium text-xs"
            >
              Comprar E-book (R$ 9,90)
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onSelectProduct('app');
              }}
              className="w-full text-center py-2.5 rounded-lg bg-[#8E513D] text-white font-medium text-xs shadow-xs"
            >
              Comprar Aplicativo (R$ 19,90)
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
