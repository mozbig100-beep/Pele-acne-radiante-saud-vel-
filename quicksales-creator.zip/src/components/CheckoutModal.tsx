import React, { useState, useEffect } from 'react';
import { 
  X, 
  Check, 
  ShieldCheck, 
  Lock, 
  Copy, 
  QrCode, 
  CreditCard, 
  Smartphone, 
  BookOpen, 
  Sparkles, 
  ArrowRight,
  ExternalLink,
  Download,
  AlertCircle,
  Settings
} from 'lucide-react';
import { PRODUCTS, formatCurrencyBRL, generatePixPayload } from '../utils/salesLogic';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedProductId: 'ebook' | 'app' | 'bundle';
  onChangeProduct: (id: 'ebook' | 'app' | 'bundle') => void;
  onOpenFullApp: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  selectedProductId,
  onChangeProduct,
  onOpenFullApp,
}) => {
  const [paymentMethod, setPaymentMethod] = useState<'pix' | 'card'>('pix');
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [copiedPix, setCopiedPix] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<'form' | 'pix_pending' | 'success'>('form');
  
  // Custom external checkout URL option for store owner
  const [showConfig, setShowConfig] = useState(false);
  const [externalCheckoutUrl, setExternalCheckoutUrl] = useState('');

  const currentProduct = PRODUCTS[selectedProductId] || PRODUCTS.ebook;
  const pixPayload = generatePixPayload(selectedProductId, currentProduct.price);

  useEffect(() => {
    // Reset state on modal open
    if (isOpen) {
      setPaymentStatus('form');
      setCopiedPix(false);
    }
  }, [isOpen, selectedProductId]);

  if (!isOpen) return null;

  const handleCopyPix = () => {
    navigator.clipboard.writeText(pixPayload);
    setCopiedPix(true);
    setTimeout(() => setCopiedPix(false), 2500);
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerEmail || !customerName) {
      alert('Por favor preencha nome e e-mail para receber o acesso.');
      return;
    }

    if (externalCheckoutUrl.trim()) {
      // If store owner configured a direct external checkout URL (e.g. Kiwify / Hotmart)
      window.open(externalCheckoutUrl.trim(), '_blank');
      onClose();
      return;
    }

    if (paymentMethod === 'pix') {
      setPaymentStatus('pix_pending');
    } else {
      // Simulated card payment approval
      setTimeout(() => {
        setPaymentStatus('success');
      }, 800);
    }
  };

  const handleSimulatePixPaid = () => {
    setPaymentStatus('success');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="relative w-full max-w-xl bg-white rounded-3xl shadow-2xl border border-[#E5DACF] overflow-hidden text-[#2C2925] animate-scaleUp my-8">
        
        {/* Top Header */}
        <div className="bg-[#FAF7F2] px-6 py-4 border-b border-[#EBE1D7] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-[#5B8C5A]" />
            <span className="text-xs font-bold uppercase tracking-wider text-[#4E443B]">
              Ambiente 100% Seguro & Criptografado
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-[#7A6F65] hover:bg-[#EAE0D5] transition-colors cursor-pointer"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Product Selector Chips inside modal */}
        <div className="p-6 pb-2">
          <label className="block text-xs font-bold text-[#63584F] uppercase tracking-wider mb-2">
            Produto Selecionado:
          </label>
          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => onChangeProduct('ebook')}
              className={`p-2.5 rounded-xl border text-left transition-all ${
                selectedProductId === 'ebook'
                  ? 'border-[#8E513D] bg-[#FBF5F1] ring-2 ring-[#8E513D]/20'
                  : 'border-[#E5DACF] bg-[#FAF8F5] opacity-75 hover:opacity-100'
              }`}
            >
              <span className="text-[10px] font-bold text-[#8E513D] block uppercase">E-book</span>
              <span className="text-xs font-bold text-[#2A2622] block truncate">Guia Prático</span>
              <span className="text-xs font-bold text-[#2A2622] font-mono">R$ 9,90</span>
            </button>

            <button
              type="button"
              onClick={() => onChangeProduct('app')}
              className={`p-2.5 rounded-xl border text-left transition-all ${
                selectedProductId === 'app'
                  ? 'border-[#8E513D] bg-[#FBF5F1] ring-2 ring-[#8E513D]/20'
                  : 'border-[#E5DACF] bg-[#FAF8F5] opacity-75 hover:opacity-100'
              }`}
            >
              <span className="text-[10px] font-bold text-[#8E513D] block uppercase">Aplicação</span>
              <span className="text-xs font-bold text-[#2A2622] block truncate">Minha Rotina</span>
              <span className="text-xs font-bold text-[#8E513D] font-mono">R$ 19,90</span>
            </button>

            <button
              type="button"
              onClick={() => onChangeProduct('bundle')}
              className={`p-2.5 rounded-xl border text-left transition-all ${
                selectedProductId === 'bundle'
                  ? 'border-[#8E513D] bg-[#FBF5F1] ring-2 ring-[#8E513D]/20'
                  : 'border-[#E5DACF] bg-[#FAF8F5] opacity-75 hover:opacity-100'
              }`}
            >
              <span className="text-[10px] font-bold text-[#2E7D32] block uppercase">Combo 83% OFF</span>
              <span className="text-xs font-bold text-[#2A2622] block truncate">E-book + App</span>
              <span className="text-xs font-bold text-[#2A2622] font-mono">R$ 24,90</span>
            </button>
          </div>
        </div>

        {/* Modal Body: State-dependent */}
        {paymentStatus === 'form' && (
          <form onSubmit={handleSubmitOrder} className="p-6 pt-3 space-y-4">
            
            {/* Customer Information */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-[#4A423A] mb-1">
                  Seu Nome Completo *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Camila Silva"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-[#D9CBC0] text-sm focus:outline-none focus:ring-2 focus:ring-[#8E513D] bg-[#FAF8F5]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-[#4A423A] mb-1">
                    E-mail para Acesso *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="seuemail@exemplo.com"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#D9CBC0] text-sm focus:outline-none focus:ring-2 focus:ring-[#8E513D] bg-[#FAF8F5]"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#4A423A] mb-1">
                    WhatsApp (com DDD)
                  </label>
                  <input
                    type="tel"
                    placeholder="(11) 98765-4321"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-[#D9CBC0] text-sm focus:outline-none focus:ring-2 focus:ring-[#8E513D] bg-[#FAF8F5]"
                  />
                </div>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div>
              <label className="block text-xs font-semibold text-[#4A423A] mb-2">
                Forma de Pagamento:
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('pix')}
                  className={`py-3 px-4 rounded-xl border flex items-center justify-center gap-2 font-semibold text-xs sm:text-sm cursor-pointer transition-all ${
                    paymentMethod === 'pix'
                      ? 'border-[#2E7D32] bg-[#EBF5EC] text-[#1E5D22] shadow-xs'
                      : 'border-[#E0D4C7] bg-[#FAF8F5] text-[#554C43]'
                  }`}
                >
                  <QrCode className="w-4 h-4 text-[#2E7D32]" />
                  <span>PIX Instantâneo</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`py-3 px-4 rounded-xl border flex items-center justify-center gap-2 font-semibold text-xs sm:text-sm cursor-pointer transition-all ${
                    paymentMethod === 'card'
                      ? 'border-[#8E513D] bg-[#FBF5F1] text-[#8E513D] shadow-xs'
                      : 'border-[#E0D4C7] bg-[#FAF8F5] text-[#554C43]'
                  }`}
                >
                  <CreditCard className="w-4 h-4 text-[#8E513D]" />
                  <span>Cartão de Crédito</span>
                </button>
              </div>
            </div>

            {/* Order Summary Box */}
            <div className="bg-[#F7F2EC] rounded-2xl p-4 border border-[#E8DFD5] space-y-2">
              <div className="flex justify-between text-xs text-[#6C6055]">
                <span>{currentProduct.name}</span>
                <span className="font-mono">{formatCurrencyBRL(currentProduct.price)}</span>
              </div>
              <div className="flex justify-between text-xs text-[#2E7D32] font-semibold">
                <span>Desconto de Lançamento</span>
                <span>- {formatCurrencyBRL(currentProduct.originalPrice - currentProduct.price)}</span>
              </div>
              <div className="pt-2 border-t border-[#DFD4C8] flex justify-between items-baseline">
                <span className="text-sm font-bold text-[#2A2622]">Total a pagar:</span>
                <span className="text-2xl font-black text-[#8E513D] font-mono">
                  {formatCurrencyBRL(currentProduct.price)}
                </span>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full bg-[#8E513D] hover:bg-[#794231] text-white py-4 px-6 rounded-2xl font-bold text-base shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{paymentMethod === 'pix' ? 'Gerar Chave PIX e Pagar' : 'Finalizar Pagamento Seguro'}</span>
              <ArrowRight className="w-5 h-5" />
            </button>

            {/* External Checkout URL settings toggle (for the store creator) */}
            <div className="pt-1 text-center">
              <button
                type="button"
                onClick={() => setShowConfig(!showConfig)}
                className="text-[11px] text-[#8F8175] hover:text-[#5E5247] flex items-center justify-center gap-1 mx-auto cursor-pointer"
              >
                <Settings className="w-3 h-3" />
                <span>{showConfig ? 'Ocultar configurações de checkout' : 'Configurar link externo (Kiwify / Hotmart)'}</span>
              </button>

              {showConfig && (
                <div className="mt-3 p-3 bg-[#F4ECE3] rounded-xl border border-[#DFD1C4] text-left text-xs space-y-2">
                  <label className="block font-semibold text-[#483F37]">
                    Link direto de checkout (Opcional):
                  </label>
                  <input
                    type="url"
                    placeholder="https://pay.kiwify.com.br/exemplo..."
                    value={externalCheckoutUrl}
                    onChange={(e) => setExternalCheckoutUrl(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg border border-[#D2C3B4] bg-white text-xs"
                  />
                  <p className="text-[10px] text-[#786D62]">
                    Se preenchido, o botão redirecionará o cliente diretamente para sua página de pagamento oficial da Kiwify, Hotmart, Braip ou Kirvano!
                  </p>
                </div>
              )}
            </div>

          </form>
        )}

        {/* Modal Body: PIX Pending Screen */}
        {paymentStatus === 'pix_pending' && (
          <div className="p-6 text-center space-y-5">
            <div className="w-12 h-12 rounded-full bg-[#E8F0E8] text-[#2E7D32] flex items-center justify-center mx-auto">
              <QrCode className="w-6 h-6" />
            </div>

            <div>
              <h3 className="font-serif-luxury text-2xl font-bold text-[#2A2622]">
                Pague via PIX para Acesso Imediato
              </h3>
              <p className="text-xs text-[#6F645A] mt-1">
                Abra seu app do banco, escolha a opção <strong>PIX Copia e Cola</strong> ou aponte a câmera.
              </p>
            </div>

            {/* QR Code graphic representation */}
            <div className="p-4 bg-white rounded-2xl border-2 border-dashed border-[#D5C7B9] inline-block shadow-xs pointer-events-none select-none">
              <div className="w-40 h-40 bg-[#FAF7F2] p-2 rounded-lg flex items-center justify-center relative border border-[#EAE0D6]">
                <QrCode className="w-36 h-36 text-[#2D2A26]" />
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="bg-[#8E513D] text-white p-1 rounded-md text-[9px] font-bold shadow-xs">
                    R$ {currentProduct.price.toFixed(2).replace('.', ',')}
                  </div>
                </div>
              </div>
            </div>

            {/* Pix Copy Code Box */}
            <div className="space-y-2 text-left">
              <label className="block text-xs font-bold text-[#554C43] uppercase tracking-wide">
                Código Pix Copia e Cola:
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  readOnly
                  value={pixPayload}
                  className="w-full px-3 py-2 text-xs font-mono bg-[#FAF8F5] border border-[#D5C7B9] rounded-xl text-[#524941] truncate"
                />
                <button
                  type="button"
                  onClick={handleCopyPix}
                  className="bg-[#2E7D32] hover:bg-[#256628] text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 shrink-0 cursor-pointer shadow-xs"
                >
                  {copiedPix ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedPix ? 'Copiado!' : 'Copiar'}</span>
                </button>
              </div>
            </div>

            {/* Simulation button for the user testing the application */}
            <div className="pt-2">
              <button
                type="button"
                onClick={handleSimulatePixPaid}
                className="w-full bg-[#8E513D] hover:bg-[#784332] text-white py-3.5 px-4 rounded-xl text-sm font-bold shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Simular Aprovação do Pagamento (Acesso Imediato)</span>
                <Check className="w-4 h-4" />
              </button>
              <p className="text-[11px] text-[#8C7E72] mt-2">
                Em produção real, a aprovação do Pix ocorre automaticamente em até 5 segundos.
              </p>
            </div>
          </div>
        )}

        {/* Modal Body: Payment Success Screen */}
        {paymentStatus === 'success' && (
          <div className="p-6 sm:p-8 text-center space-y-5 animate-fadeIn">
            <div className="w-16 h-16 rounded-full bg-[#E5F3E5] text-[#2E7D32] flex items-center justify-center mx-auto shadow-sm">
              <Check className="w-9 h-9 stroke-[3]" />
            </div>

            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#2E7D32] bg-[#E8F0E8] px-3 py-1 rounded-full">
                Pagamento Aprovado com Sucesso!
              </span>
              <h3 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#2A2622] mt-3">
                Bem-vindo(a) à sua Nova Pele!
              </h3>
              <p className="text-xs sm:text-sm text-[#665B51] mt-1.5 max-w-md mx-auto">
                Seus comprovantes foram enviados para <strong>{customerEmail || 'seu e-mail'}</strong>. 
                Você já pode acessar seus materiais agora mesmo:
              </p>
            </div>

            {/* Action buttons to access products */}
            <div className="space-y-3 pt-2 max-w-md mx-auto">
              {(selectedProductId === 'app' || selectedProductId === 'bundle') && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenFullApp();
                  }}
                  className="w-full bg-[#8E513D] hover:bg-[#794231] text-white py-4 px-5 rounded-2xl font-bold text-sm sm:text-base shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Smartphone className="w-5 h-5" />
                  <span>Abrir Aplicativo "Minha Rotina" Agora</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              )}

              {(selectedProductId === 'ebook' || selectedProductId === 'bundle') && (
                <button
                  type="button"
                  onClick={() => {
                    // Triggers sample PDF or chapter view
                    alert('Download iniciado! O arquivo PDF "Guia_Pratico_Pele_Acne.pdf" foi gerado.');
                  }}
                  className="w-full bg-[#FAF7F2] hover:bg-[#F2ECE4] text-[#463D35] border-2 border-[#D8C7B9] py-3.5 px-5 rounded-2xl font-bold text-sm shadow-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-4 h-4 text-[#8E513D]" />
                  <span>Baixar E-book em PDF (Alta Resolução)</span>
                </button>
              )}
            </div>

            <p className="text-xs text-[#8A7C70] pt-2">
              Dúvidas ou suporte? Envie uma mensagem para nosso time pelo WhatsApp ou e-mail.
            </p>
          </div>
        )}

      </div>
    </div>
  );
};
