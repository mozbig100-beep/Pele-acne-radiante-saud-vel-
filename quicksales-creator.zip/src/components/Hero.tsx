import React from 'react';
import { 
  Sparkles, 
  CheckCircle2, 
  ArrowRight, 
  Smartphone, 
  BookOpen, 
  ShieldCheck, 
  Zap, 
  Star,
  Users
} from 'lucide-react';
import { formatCurrencyBRL } from '../utils/salesLogic';

interface HeroProps {
  onSelectProduct: (productId: 'ebook' | 'app' | 'bundle') => void;
  onScrollToSection: (sectionId: string) => void;
}

export const Hero: React.FC<HeroProps> = ({ onSelectProduct, onScrollToSection }) => {
  return (
    <section id="hero" className="relative overflow-hidden pt-8 pb-16 lg:pt-14 lg:pb-24">
      {/* Background radial gradients for warm skincare aesthetic */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-[650px] -z-10 pointer-events-none opacity-60">
        <div className="absolute top-10 left-10 w-96 h-96 rounded-full bg-[#F3D5C5] blur-3xl filter opacity-40 mix-blend-multiply" />
        <div className="absolute top-20 right-10 w-96 h-96 rounded-full bg-[#E5D2C2] blur-3xl filter opacity-50 mix-blend-multiply" />
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Top Tagline / Micro-badge */}
        <div className="flex flex-col items-center text-center space-y-4 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#EFE4DC] border border-[#DFCFC4] text-[#7A4533] text-xs font-semibold tracking-wide uppercase shadow-2xs">
            <Sparkles className="w-3.5 h-3.5 text-[#A25A44]" />
            <span>Método Simples, Eficaz & Científico</span>
          </div>

          {/* Main Title with Editorial Serif Flair */}
          <h1 className="font-serif-luxury text-4xl sm:text-5xl lg:text-6xl text-[#282420] font-bold leading-[1.12] tracking-tight">
            Pele limpa, equilibrada e livre de acne{' '}
            <span className="italic font-normal text-[#8E513D] block sm:inline">
              sem gastar fortunas.
            </span>
          </h1>

          {/* Subheading */}
          <p className="text-base sm:text-lg text-[#61574F] font-normal leading-relaxed max-w-2xl">
            Pare de testar receitas da internet que inflamam sua pele. Tenha em mãos o guia definitivo 
            passo a passo e o aplicativo inteligente para organizar sua rotina diária contra cravos e espinhas.
          </p>

          {/* Trust and Rating indicator */}
          <div className="flex flex-wrap items-center justify-center gap-3 text-xs sm:text-sm text-[#6A6057] pt-1">
            <div className="flex items-center text-[#DF9B2A]">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-current" />
              ))}
            </div>
            <span className="font-semibold text-[#2D2A26]">4.9 / 5.0</span>
            <span className="text-[#B3A69C]">•</span>
            <span className="flex items-center gap-1.5">
              <Users className="w-4 h-4 text-[#8E513D]" />
              <strong>+4.800 pessoas</strong> já transformaram sua rotina
            </span>
          </div>
        </div>

        {/* Dual Product Showcase Cards in Hero */}
        <div className="mt-12 lg:mt-16 grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch max-w-5xl mx-auto">
          
          {/* Product 1: E-book Guia Prático */}
          <div className="group relative bg-[#F7F2EB] border-2 border-[#E5DAD0] hover:border-[#8E513D]/40 rounded-3xl p-6 sm:p-8 flex flex-col justify-between transition-all duration-300 hover:shadow-xl">
            <div className="absolute -top-3.5 left-6 bg-[#685548] text-white text-[11px] font-bold px-3 py-1 rounded-full uppercase tracking-wider flex items-center gap-1 shadow-xs">
              <BookOpen className="w-3.5 h-3.5" />
              Produto 1: Livro Digital
            </div>

            <div>
              <div className="flex items-start justify-between gap-4 mt-2 mb-4">
                <div>
                  <span className="text-xs font-semibold text-[#8E513D] uppercase tracking-wider block">
                    Guia Prático em PDF
                  </span>
                  <h3 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#2D2A26] mt-1">
                    Cuidados com a Pele Acne
                  </h3>
                  <p className="text-xs sm:text-sm text-[#6B6159] mt-1.5">
                    Dicas práticas, simples e eficazes para recuperar a saúde da sua pele.
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-xs text-[#9B8F85] line-through block">de R$ 47,00</span>
                  <span className="text-2xl sm:text-3xl font-bold text-[#2D2A26] font-mono">
                    R$ 9,90
                  </span>
                  <span className="text-[11px] text-[#2E7D32] font-semibold block">Pagamento Único</span>
                </div>
              </div>

              {/* Visual mini-mockup of the e-book */}
              <div className="my-5 bg-[#EFE8DE] rounded-2xl p-4 border border-[#DFD3C6] flex items-center gap-4">
                <div className="w-20 h-28 bg-[#DFD0C2] rounded-lg shadow-md border border-[#CBBBAA] p-2 flex flex-col justify-between shrink-0 text-center">
                  <span className="text-[7px] font-bold uppercase tracking-wider text-[#734A3C]">Guia Prático</span>
                  <div className="text-[9px] font-serif-luxury font-bold text-[#2C2925] leading-tight">
                    CUIDADOS COM A PELE ACNE
                  </div>
                  <div className="text-[6px] text-[#695D54]">Passo a Passo</div>
                </div>

                <div className="space-y-1.5 text-xs text-[#524942]">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#5B8C5A] shrink-0" />
                    <span>Pele limpa & equilíbrio na medida</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#5B8C5A] shrink-0" />
                    <span>Cica, Niacinamida e Ácido Salicílico</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#5B8C5A] shrink-0" />
                    <span>Tratamentos que realmente funcionam</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#5B8C5A] shrink-0" />
                    <span>Leitura fácil no celular ou computador</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-2.5 pt-2">
              <button
                onClick={() => onSelectProduct('ebook')}
                className="w-full bg-[#413B35] hover:bg-[#2C2723] text-white py-3.5 px-5 rounded-2xl font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer group-hover:scale-[1.01]"
              >
                <span>Garantir E-book por R$ 9,90</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => onScrollToSection('ebook-preview')}
                className="w-full text-center text-xs font-semibold text-[#7D5344] hover:text-[#503227] py-1 cursor-pointer underline underline-offset-2"
              >
                Ver sumário & amostra grátis
              </button>
            </div>
          </div>

          {/* Product 2: Aplicação Interativa Minha Rotina */}
          <div className="group relative bg-[#FFFFFF] border-2 border-[#8E513D] rounded-3xl p-6 sm:p-8 flex flex-col justify-between transition-all duration-300 shadow-lg hover:shadow-2xl ring-4 ring-[#8E513D]/10">
            <div className="absolute -top-3.5 left-6 bg-[#8E513D] text-white text-[11px] font-bold px-3 py-1 rounded-full uppercase tracking-wider flex items-center gap-1 shadow-sm">
              <Zap className="w-3.5 h-3.5 text-[#FFD166]" />
              Produto 2: Aplicação Interativa
            </div>

            <div>
              <div className="flex items-start justify-between gap-4 mt-2 mb-4">
                <div>
                  <span className="text-xs font-semibold text-[#8E513D] uppercase tracking-wider block">
                    App Web & Mobile Inteligente
                  </span>
                  <h3 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#2D2A26] mt-1">
                    Minha Rotina Skincare
                  </h3>
                  <p className="text-xs sm:text-sm text-[#6B6159] mt-1.5">
                    Seu assistente de hábitos com checklist diário, gráficos e lembretes.
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-xs text-[#9B8F85] line-through block">de R$ 97,00</span>
                  <span className="text-2xl sm:text-3xl font-bold text-[#8E513D] font-mono">
                    R$ 19,90
                  </span>
                  <span className="text-[11px] text-[#2E7D32] font-semibold block">Acesso Vitalício</span>
                </div>
              </div>

              {/* Visual mini-mockup of the App */}
              <div className="my-5 bg-[#FAF7F2] rounded-2xl p-4 border border-[#EBE2D8] flex items-center gap-4">
                <div className="w-20 h-28 bg-[#1E1B18] rounded-xl p-1.5 shadow-md flex flex-col justify-between shrink-0 text-white border border-[#3C3631]">
                  <div className="flex justify-between items-center text-[6px] text-zinc-400">
                    <span>9:41</span>
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  </div>
                  <div className="bg-[#2D2925] p-1 rounded">
                    <span className="text-[7px] text-[#E5D2C2] block font-semibold">Progresso</span>
                    <div className="w-full bg-zinc-700 h-1.5 rounded-full overflow-hidden mt-0.5">
                      <div className="bg-[#C68B70] h-full w-[75%] rounded-full"></div>
                    </div>
                  </div>
                  <div className="space-y-0.5">
                    <div className="h-1 bg-zinc-700 rounded w-full"></div>
                    <div className="h-1 bg-[#8E513D] rounded w-4/5"></div>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs text-[#524942]">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#5B8C5A] shrink-0" />
                    <span>Checklist inteligente Manhã & Noite</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#5B8C5A] shrink-0" />
                    <span>Acompanhe o progresso semanal (70%+)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#5B8C5A] shrink-0" />
                    <span>Gerencie seus produtos e cosméticos</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#5B8C5A] shrink-0" />
                    <span>Dicas diárias de dermatologistas</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-2.5 pt-2">
              <button
                onClick={() => onSelectProduct('app')}
                className="w-full bg-[#8E513D] hover:bg-[#794231] text-white py-3.5 px-5 rounded-2xl font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer group-hover:scale-[1.01]"
              >
                <span>Acessar Aplicativo por R$ 19,90</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => onScrollToSection('demo-app')}
                className="w-full text-center text-xs font-semibold text-[#8E513D] hover:text-[#5F3325] py-1 cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>Testar a demonstração interativa agora</span>
              </button>
            </div>
          </div>

        </div>

        {/* Big Value Banner: Combo Promo */}
        <div className="mt-8 max-w-5xl mx-auto bg-gradient-to-r from-[#2F2A25] via-[#3E3731] to-[#2F2A25] rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 border border-[#524942]">
          <div className="space-y-2 text-center md:text-left">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#8E513D] text-[#FFF0E8] text-[11px] font-bold uppercase tracking-wider">
              <Sparkles className="w-3 h-3 text-[#FFD166]" />
              Combo Recomendado (83% de Desconto)
            </div>
            <h3 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#F7F2EB]">
              Leve os 2 Juntos: E-book + Aplicativo
            </h3>
            <p className="text-xs sm:text-sm text-[#D7C9BD] max-w-xl">
              Aprenda a ciência e os ativos no E-book e execute todos os dias com o Aplicativo.
              De <span className="line-through text-zinc-400">R$ 144,00</span> por apenas:
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-4 shrink-0 w-full md:w-auto">
            <div className="text-center md:text-right">
              <span className="text-3xl sm:text-4xl font-extrabold text-[#FFD166] font-mono">
                R$ 24,90
              </span>
              <span className="block text-[11px] text-zinc-300">ou 3x no cartão</span>
            </div>
            <button
              onClick={() => onSelectProduct('bundle')}
              className="w-full sm:w-auto bg-[#C68B70] hover:bg-[#B3795E] text-white px-7 py-4 rounded-2xl font-bold text-sm shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Quero o Combo Completo</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Fast Assurance Icons */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto pt-4 border-t border-[#E8DDD2]">
          <div className="flex items-center gap-2.5 text-xs text-[#5C534B]">
            <ShieldCheck className="w-5 h-5 text-[#5B8C5A] shrink-0" />
            <span>Garantia de 7 dias incondicional</span>
          </div>
          <div className="flex items-center gap-2.5 text-xs text-[#5C534B]">
            <Zap className="w-5 h-5 text-[#C68B70] shrink-0" />
            <span>Acesso imediato no seu e-mail/WhatsApp</span>
          </div>
          <div className="flex items-center gap-2.5 text-xs text-[#5C534B]">
            <Smartphone className="w-5 h-5 text-[#8E513D] shrink-0" />
            <span>Funciona em qualquer celular ou PC</span>
          </div>
          <div className="flex items-center gap-2.5 text-xs text-[#5C534B]">
            <CheckCircle2 className="w-5 h-5 text-[#5B8C5A] shrink-0" />
            <span>Sem mensalidades ou cobranças futuras</span>
          </div>
        </div>

      </div>
    </section>
  );
};
