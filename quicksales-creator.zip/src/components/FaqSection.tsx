import React, { useState } from 'react';
import { ChevronDown, HelpCircle, Sparkles } from 'lucide-react';

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: 'Como vou receber o acesso ao E-book e ao Aplicativo?',
      a: 'Assim que o pagamento for aprovado (no PIX ou Cartão), os dados de acesso são enviados imediatamente para o seu e-mail e WhatsApp cadastrados. O E-book vem em arquivo PDF de alta definição pronto para baixar ou imprimir, e a aplicação tem acesso web instantâneo no seu navegador.'
    },
    {
      q: 'O aplicativo funciona no iPhone e no celular Android?',
      a: 'Sim! A aplicação "Minha Rotina" foi desenvolvida com tecnologia web moderna (PWA). Você pode usá-la direto pelo Safari, Chrome ou qualquer navegador do celular, tablet ou computador, e até fixar o ícone na tela inicial como um app nativo, sem ocupar a memória do aparelho.'
    },
    {
      q: 'O valor de R$ 9,90 e R$ 19,90 é mensalidade?',
      a: 'Não! É pagamento único. Você paga uma única vez e tem acesso vitalício ao material e à aplicação, sem nenhuma cobrança recorrente futura.'
    },
    {
      q: 'Preciso comprar produtos de marcas caras?',
      a: 'De jeito nenhum! O método foi criado especificamente para ensinar você a identificar os ativos certos (como Ácido Salicílico, Cica e Niacinamida) e traz uma lista de produtos de farmácia populares e baratos (a partir de R$ 18 a R$ 35) que possuem resultados clínicos comprovados.'
    },
    {
      q: 'Serve para qualquer grau de acne?',
      a: 'O guia e a aplicação são ideais para acne não-cística e inflamatória leve a moderada (graus 1 e 2), oleosidade excessiva, poros dilatados e marcas pós-acne. Se você possui acne severa (nódulos ou cistos dolorosos profundos), o método auxilia na higienização suave, mas recomendamos também acompanhamento com um médico dermatologista.'
    },
    {
      q: 'E se eu não gostar ou não funcionar para mim?',
      a: 'Você está protegido pela nossa Garantia Blindada de 7 Dias. Se dentro de 7 dias você achar que o conteúdo não é para você, devolvemos 100% do valor pago imediatamente, sem questionamentos.'
    }
  ];

  return (
    <section id="faq" className="py-16 sm:py-24 bg-[#FAF7F2] border-t border-[#E8DDD2]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EAD8CD] text-[#7A4B3A] text-xs font-bold uppercase tracking-wider mb-3">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Tire Suas Dúvidas</span>
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl font-bold text-[#2A2622]">
            Perguntas Frequentes
          </h2>
          <p className="text-sm text-[#675C53] mt-2">
            Respostas claras para as principais perguntas sobre os materiais e acesso.
          </p>
        </div>

        {/* Accordion list */}
        <div className="space-y-3">
          {faqs.map((faq, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl border border-[#E5DACF] overflow-hidden transition-all shadow-xs"
            >
              <button
                onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
                className="w-full text-left p-5 flex justify-between items-center gap-4 cursor-pointer hover:bg-[#FAF6F1] transition-colors"
              >
                <span className="text-sm sm:text-base font-bold text-[#2C2824]">
                  {faq.q}
                </span>
                <ChevronDown
                  className={`w-5 h-5 text-[#8E513D] shrink-0 transition-transform duration-300 ${
                    openIndex === idx ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {openIndex === idx && (
                <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-[#5C5248] leading-relaxed border-t border-[#F2ECE5]">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
