import React, { useState } from 'react';
import { BookOpen, CheckCircle2, ArrowRight, Sparkles, ChevronRight, Download, FileText, Eye } from 'lucide-react';

interface EbookPreviewProps {
  onSelectProduct: (productId: 'ebook' | 'app' | 'bundle') => void;
}

export const EbookPreview: React.FC<EbookPreviewProps> = ({ onSelectProduct }) => {
  const [activeChapter, setActiveChapter] = useState(0);

  const chapters = [
    {
      title: 'Capítulo 1: A Falsa Ilusão da Pele Seca',
      subtitle: 'Por que sabonetes adstringentes fortes pioram a acne',
      content:
        'A maioria das pessoas com acne comete o erro fatal de usar sabonetes ultra-agressivos para "secar" a pele. O resultado é o infame efeito rebote: as glândulas sebáceas entendem que a barreira protetora foi danificada e produzem 3x mais óleo nas horas seguintes. Neste capítulo, você descobre como limpar gentilmente preservando o microbioma protetor.',
      badge: 'Fundamento Essencial'
    },
    {
      title: 'Capítulo 2: Os 3 Ativos Comprovados pela Ciência',
      subtitle: 'Cica, Niacinamida e Ácido Salicílico 2%',
      content:
        'Não gaste dinheiro com 10 produtos diferentes. Estudos dermatológicos apontam que a combinação de Ácido Salicílico (lipofílico, penetra no poro desobstruindo o sebo), Niacinamida (anti-inflamatória, reduz vermelhidão e manchas) e Cica (Centella Asiática, regenera a pele irritada) entrega mais de 85% do resultado clínico necessário.',
      badge: 'O Trio de Ouro'
    },
    {
      title: 'Capítulo 3: A Rotina Descomplicada de 4 Minutos',
      subtitle: 'Passo a passo matinal e noturno sem complicação',
      content:
        'Você não precisa de 10 passos cansativos. Uma rotina de 3 passos pela manhã (Limpeza Suave + Hidratação Leve + Protetor FPS 50) e 3 passos à noite (Limpeza + Sérum Antiacne Ativo + Hidratante Reparador) é suficiente para ver resultados visíveis já nas primeiras 2 a 3 semanas.',
      badge: 'Prática Imediata'
    },
    {
      title: 'Capítulo 4: Guia de Compras de Farmácia',
      subtitle: 'Opções baratas e eficazes que custam menos de R$ 35',
      content:
        'Marcas de luxo cobram R$ 200 por potes com fórmulas simples. Neste capítulo entregamos uma lista detalhada com nomes comerciais de produtos de farmácia brasileira baratos, aprovados pela Anvisa e dermatologicamente testados que possuem a mesma eficácia por uma fração do preço.',
      badge: 'Economia Real'
    }
  ];

  return (
    <section id="ebook-preview" className="py-16 sm:py-24 bg-[#FAF7F2]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EAD8CD] text-[#7A4B3A] text-xs font-bold uppercase tracking-wider mb-3">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Conteúdo Exclusivo do Livro Digital</span>
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2A2622]">
            O que você vai aprender no <br className="hidden sm:block" />
            <span className="italic font-normal text-[#8E513D]">Guia Prático Cuidados com a Pele Acne</span>
          </h2>
          <p className="text-sm sm:text-base text-[#665B52] mt-3">
            Um guia direto ao ponto, sem termos médicos difíceis, com soluções que você pode aplicar hoje mesmo.
          </p>
        </div>

        {/* Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center max-w-5xl mx-auto">
          
          {/* Left: Book Cover & Feature List */}
          <div className="lg:col-span-5 flex flex-col items-center">
            {/* Realistic Book Cover Mockup matching Image 1 */}
            <div className="w-64 sm:w-72 bg-[#EADDCF] rounded-2xl p-5 shadow-2xl border-4 border-[#DDD0C2] transform hover:-rotate-1 transition-transform duration-300">
              <div className="bg-[#FAF7F2] rounded-xl p-4 border border-[#E0D3C5] flex flex-col justify-between h-[360px] text-center shadow-inner">
                
                <div>
                  <div className="inline-block px-2.5 py-0.5 rounded-full bg-[#EFE4DA] text-[#8E513D] text-[10px] font-bold uppercase tracking-widest mb-3">
                    📖 Guia Prático
                  </div>
                  <h3 className="font-serif-luxury text-2xl font-bold text-[#2C2925] tracking-tight leading-none">
                    CUIDADOS
                  </h3>
                  <div className="text-xs font-serif-luxury tracking-widest text-[#7A6D63] my-0.5">
                    COM A
                  </div>
                  <h4 className="font-serif-luxury text-2xl font-bold text-[#2C2925] tracking-tight leading-none mb-2">
                    PELE ACNE
                  </h4>
                  <p className="text-[10px] text-[#6E6359] leading-tight px-2">
                    Dicas práticas, simples e eficazes para pele saudável.
                  </p>
                </div>

                {/* Highlights inside mockup */}
                <div className="bg-[#F4ECE3] rounded-lg p-2.5 my-2 space-y-1 text-left text-[11px] text-[#554C44] border border-[#E5DACD]">
                  <div className="flex items-center gap-1.5 font-medium">
                    <span className="text-[#5B8C5A]">✔</span> Pele limpa e equilibrada
                  </div>
                  <div className="flex items-center gap-1.5 font-medium">
                    <span className="text-[#5B8C5A]">✔</span> Hidratação na medida certa
                  </div>
                  <div className="flex items-center gap-1.5 font-medium">
                    <span className="text-[#5B8C5A]">✔</span> Tratamentos que funcionam
                  </div>
                  <div className="flex items-center gap-1.5 font-medium">
                    <span className="text-[#5B8C5A]">✔</span> Rotina rápida de cuidados
                  </div>
                </div>

                <div className="pt-2 border-t border-[#E8DFD5] flex justify-between items-center text-[10px] text-[#86776C] font-semibold">
                  <span>Pele Saudável</span>
                  <span>Guia Passo a Passo</span>
                </div>

              </div>
            </div>

            {/* Quick purchase reminder */}
            <div className="mt-5 text-center">
              <span className="text-xs text-[#7A6F66] block">Acesso vitalício em PDF no celular ou tablet</span>
              <div className="text-xl font-extrabold text-[#2C2925] font-mono mt-0.5">
                Apenas R$ 9,90
              </div>
            </div>
          </div>

          {/* Right: Interactive Chapter Tabs */}
          <div className="lg:col-span-7 space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-[#8E513D]">
              Explore uma amostra dos capítulos
            </span>

            <div className="space-y-2.5">
              {chapters.map((ch, idx) => (
                <div
                  key={idx}
                  onClick={() => setActiveChapter(idx)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                    activeChapter === idx
                      ? 'bg-white border-[#8E513D] shadow-md ring-2 ring-[#8E513D]/10'
                      : 'bg-[#F5EFEB] border-[#E5DACF] hover:bg-white'
                  }`}
                >
                  <div className="flex justify-between items-start gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-bold text-[#8E513D] uppercase tracking-wide">
                          {ch.badge}
                        </span>
                      </div>
                      <h4 className="text-sm sm:text-base font-bold text-[#2A2622] mt-0.5">
                        {ch.title}
                      </h4>
                      <p className="text-xs text-[#7A6F66] font-medium">
                        {ch.subtitle}
                      </p>
                    </div>
                    <ChevronRight 
                      className={`w-5 h-5 text-[#8E513D] transition-transform ${
                        activeChapter === idx ? 'rotate-90' : ''
                      }`} 
                    />
                  </div>

                  {activeChapter === idx && (
                    <div className="mt-3 pt-3 border-t border-[#F0E6DD] text-xs sm:text-sm text-[#554C44] leading-relaxed animate-fadeIn">
                      {ch.content}
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="pt-3 flex flex-col sm:flex-row gap-3">
              <button
                onClick={() => onSelectProduct('ebook')}
                className="flex-1 bg-[#423C36] hover:bg-[#2B2723] text-white py-3.5 px-5 rounded-xl font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Baixar o E-book Completo (R$ 9,90)</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={() => onSelectProduct('bundle')}
                className="bg-[#EFE5DC] hover:bg-[#E5D6C9] text-[#7A4533] py-3.5 px-4 rounded-xl font-bold text-xs sm:text-sm border border-[#DAC9BA] transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-[#C68B70]" />
                <span>Levar E-book + App (R$ 24,90)</span>
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
