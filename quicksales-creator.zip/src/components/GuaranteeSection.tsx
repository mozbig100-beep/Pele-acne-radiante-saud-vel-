import React from 'react';
import { ShieldCheck, ArrowRight, HeartHandshake } from 'lucide-react';

interface GuaranteeProps {
  onSelectProduct: (productId: 'ebook' | 'app' | 'bundle') => void;
}

export const GuaranteeSection: React.FC<GuaranteeProps> = ({ onSelectProduct }) => {
  return (
    <section id="garantia" className="py-16 bg-[#FAF7F2]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="bg-[#EFE8E0] rounded-3xl p-7 sm:p-10 border-2 border-[#DFCFC3] shadow-md flex flex-col md:flex-row items-center gap-8">
          
          {/* Big Guarantee Shield */}
          <div className="shrink-0 flex flex-col items-center justify-center w-36 h-36 rounded-full bg-[#E3D4C6] border-4 border-[#CDBAA9] text-[#784433] shadow-inner text-center p-3">
            <ShieldCheck className="w-10 h-10 stroke-[2.5]" />
            <span className="text-xl font-black font-mono leading-none mt-1">7 DIAS</span>
            <span className="text-[10px] uppercase font-bold tracking-wider leading-tight">Garantia Total</span>
          </div>

          {/* Guarantee copy */}
          <div className="space-y-3 text-center md:text-left flex-1">
            <span className="text-xs font-bold uppercase tracking-wider text-[#8E513D]">
              Risco Zero Para Você
            </span>
            <h3 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#2A2622]">
              Garantia Incondicional de Satisfação
            </h3>
            <p className="text-xs sm:text-sm text-[#5E534A] leading-relaxed">
              Temos tanta certeza de que o <strong>Guia Prático</strong> e o <strong>Aplicativo Minha Rotina</strong> vão transformar o seu autocuidado que oferecemos 7 dias completos de teste. Se por qualquer motivo você não gostar, basta enviar uma mensagem e devolveremos 100% do seu dinheiro, centavo por centavo. Sem letras miúdas.
            </p>

            <div className="pt-2">
              <button
                onClick={() => onSelectProduct('bundle')}
                className="bg-[#8E513D] hover:bg-[#794231] text-white py-3 px-6 rounded-xl font-bold text-xs sm:text-sm shadow-sm transition-all inline-flex items-center gap-2 cursor-pointer"
              >
                <span>Experimentar Sem Riscos por 7 Dias</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
