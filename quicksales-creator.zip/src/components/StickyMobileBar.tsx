import React from 'react';
import { ArrowRight, Sparkles, Smartphone, BookOpen } from 'lucide-react';

interface StickyMobileBarProps {
  onSelectProduct: (productId: 'ebook' | 'app' | 'bundle') => void;
}

export const StickyMobileBar: React.FC<StickyMobileBarProps> = ({ onSelectProduct }) => {
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#FAF7F2]/95 backdrop-blur-md border-t border-[#DFD3C6] px-4 py-2.5 shadow-2xl flex items-center justify-between gap-3">
      <div className="flex flex-col">
        <span className="text-[10px] uppercase font-bold text-[#8E513D] tracking-wider leading-none">
          Oferta de Lançamento
        </span>
        <div className="flex items-baseline gap-1 mt-0.5">
          <span className="text-base font-extrabold text-[#2C2925] font-mono leading-none">
            R$ 9,90
          </span>
          <span className="text-[10px] text-[#786D62]">a R$ 19,90</span>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={() => onSelectProduct('ebook')}
          className="bg-[#484039] text-white px-3 py-2 rounded-xl text-xs font-bold shadow-xs flex items-center gap-1 cursor-pointer"
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>E-book</span>
        </button>

        <button
          onClick={() => onSelectProduct('app')}
          className="bg-[#8E513D] text-white px-3.5 py-2 rounded-xl text-xs font-bold shadow-md flex items-center gap-1 cursor-pointer"
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>App R$ 19,90</span>
        </button>
      </div>
    </div>
  );
};
