import React, { useState } from 'react';
import { 
  X, 
  Check, 
  Sun, 
  Moon, 
  Sparkles, 
  Calendar, 
  Plus, 
  Trash2, 
  Award, 
  Bell, 
  ArrowLeft,
  Flame,
  CheckCircle2,
  Droplets
} from 'lucide-react';
import { calculateRoutineProgress } from '../utils/salesLogic';

interface FullAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface RoutineItem {
  id: string;
  name: string;
  category: string;
  done: boolean;
  notes: string;
}

export const FullAppModal: React.FC<FullAppModalProps> = ({ isOpen, onClose }) => {
  const [period, setPeriod] = useState<'morning' | 'night'>('morning');
  const [userName, setUserName] = useState('Camila');
  
  const [morningSteps, setMorningSteps] = useState<RoutineItem[]>([
    { id: 'm1', name: 'Gel de Limpeza Suave', category: 'Limpeza', done: true, notes: 'Aplicar na pele úmida por 60 segundos' },
    { id: 'm2', name: 'Tônico Facial Calmante', category: 'Equilíbrio', done: true, notes: 'Com camomila e centella asiática' },
    { id: 'm3', name: 'Sérum Niacinamida 5%', category: 'Controle de Sebo', done: false, notes: '4 gotinhas espalhadas no rosto' },
    { id: 'm4', name: 'Gel Creme Hidratante Oil-Free', category: 'Hidratação', done: false, notes: 'Textura aquosa não-comedogênica' },
    { id: 'm5', name: 'Protetor Solar Facial Toque Seco FPS 50', category: 'Proteção', done: false, notes: 'Fundamental para não manchar cicatrizes' }
  ]);

  const [nightSteps, setNightSteps] = useState<RoutineItem[]>([
    { id: 'n1', name: 'Dupla Limpeza (Demaquilante/Cleansing Oil + Gel)', category: 'Limpeza Profunda', done: true, notes: 'Remove poluição e filtro solar do dia' },
    { id: 'n2', name: 'Sérum Ácido Salicílico 2%', category: 'Tratamento', done: false, notes: 'Desobstrui poros e reduz cravos' },
    { id: 'n3', name: 'Creme Reparador de Cica (Centella Asiática)', category: 'Regeneração', done: false, notes: 'Acalma qualquer vermelhidão noturna' }
  ]);

  const [showAddCustom, setShowAddCustom] = useState(false);
  const [newStepName, setNewStepName] = useState('');
  const [newStepCat, setNewStepCat] = useState('');

  if (!isOpen) return null;

  const currentSteps = period === 'morning' ? morningSteps : nightSteps;
  const setSteps = period === 'morning' ? setMorningSteps : setNightSteps;

  const toggleStep = (id: string) => {
    setSteps(prev => prev.map(s => s.id === id ? { ...s, done: !s.done } : s));
  };

  const addCustomStep = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStepName.trim()) return;
    const newItem: RoutineItem = {
      id: Date.now().toString(),
      name: newStepName.trim(),
      category: newStepCat.trim() || 'Cuidado Especial',
      done: false,
      notes: 'Passo personalizado adicionado por você'
    };
    setSteps(prev => [...prev, newItem]);
    setNewStepName('');
    setNewStepCat('');
    setShowAddCustom(false);
  };

  const removeStep = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSteps(prev => prev.filter(s => s.id !== id));
  };

  const progress = calculateRoutineProgress(currentSteps.map(s => s.done));

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/75 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4">
      <div className="relative w-full max-w-2xl bg-[#FAF7F2] rounded-3xl shadow-2xl border border-[#E0D3C5] overflow-hidden text-[#2C2925] max-h-[92vh] flex flex-col my-auto font-sans">
        
        {/* Top bar with Back Button */}
        <div className="bg-[#2C2824] text-white px-5 py-3.5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-zinc-300 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer flex items-center gap-1.5 text-xs font-semibold"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Voltar à Página</span>
            </button>
            <span className="text-zinc-500">|</span>
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#C68B70]" />
              <span className="font-serif-luxury text-base font-bold">Minha Rotina Skincare</span>
              <span className="text-[10px] bg-[#5B8C5A] text-white px-2 py-0.5 rounded font-bold uppercase">
                App Ativo
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors cursor-pointer"
            aria-label="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Interior Container */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-7 space-y-6">
          
          {/* Greeting & Streak Header */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-white p-5 rounded-2xl border border-[#E9DFD4] shadow-xs">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-serif-luxury text-2xl font-bold text-[#2A2622]">
                  Olá, {userName}!
                </h3>
                <span className="text-lg">✨</span>
              </div>
              <p className="text-xs text-[#7A6F65] mt-0.5">
                Seguir sua sequência diária reduz 80% das chances de novas espinhas.
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="bg-[#FAF2EB] border border-[#E7D6C7] px-3 py-1.5 rounded-xl flex items-center gap-2 text-xs font-bold text-[#8E513D]">
                <Flame className="w-4 h-4 text-[#D95338]" />
                <span>Sequência: 4 dias</span>
              </div>
            </div>
          </div>

          {/* Morning / Night Switcher */}
          <div className="flex bg-[#EFE7DE] p-1.5 rounded-2xl">
            <button
              onClick={() => setPeriod('morning')}
              className={`flex-1 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                period === 'morning'
                  ? 'bg-white text-[#2C2925] shadow-xs'
                  : 'text-[#7A6E64] hover:text-[#2C2925]'
              }`}
            >
              <Sun className="w-4 h-4 text-[#DF9B2A]" />
              <span>Rotina da Manhã</span>
            </button>

            <button
              onClick={() => setPeriod('night')}
              className={`flex-1 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                period === 'night'
                  ? 'bg-white text-[#2C2925] shadow-xs'
                  : 'text-[#7A6E64] hover:text-[#2C2925]'
              }`}
            >
              <Moon className="w-4 h-4 text-[#606E8C]" />
              <span>Rotina da Noite</span>
            </button>
          </div>

          {/* Progress Indicator */}
          <div className="bg-white rounded-2xl p-5 border border-[#E8DFD5] shadow-xs space-y-2">
            <div className="flex justify-between items-center text-xs font-bold text-[#443C35]">
              <span>Progresso da {period === 'morning' ? 'Manhã' : 'Noite'}</span>
              <span className="text-sm font-extrabold text-[#8E513D] font-mono">{progress}%</span>
            </div>
            <div className="w-full bg-[#EFE8E1] h-3 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-[#C68B70] to-[#8E513D] h-full rounded-full transition-all duration-500 ease-out"
                style={{ width: `${progress}%` }}
              />
            </div>
            {progress === 100 && (
              <p className="text-xs text-[#2E7D32] font-semibold flex items-center gap-1.5 pt-1">
                <CheckCircle2 className="w-4 h-4" />
                Excelente! Você concluiu todos os passos previstos.
              </p>
            )}
          </div>

          {/* Steps List */}
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-xs font-bold text-[#554C44] uppercase tracking-wider">
                Passo a Passo Personalizado
              </span>
              <button
                onClick={() => setShowAddCustom(!showAddCustom)}
                className="text-xs text-[#8E513D] hover:text-[#6F3827] font-semibold flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Adicionar produto</span>
              </button>
            </div>

            {/* Custom product form */}
            {showAddCustom && (
              <form onSubmit={addCustomStep} className="bg-[#FAF2EB] p-4 rounded-2xl border border-[#DFCBB9] space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <input
                    type="text"
                    required
                    placeholder="Nome do produto ou ativo (ex: Água Termal)"
                    value={newStepName}
                    onChange={(e) => setNewStepName(e.target.value)}
                    className="px-3 py-2 text-xs rounded-xl border border-[#DAC9B9] bg-white"
                  />
                  <input
                    type="text"
                    placeholder="Categoria (ex: Hidratação extra)"
                    value={newStepCat}
                    onChange={(e) => setNewStepCat(e.target.value)}
                    className="px-3 py-2 text-xs rounded-xl border border-[#DAC9B9] bg-white"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddCustom(false)}
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold text-[#6E6359]"
                  >
                    Cancelar
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-[#8E513D] text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer"
                  >
                    Salvar na Rotina
                  </button>
                </div>
              </form>
            )}

            <div className="space-y-2.5">
              {currentSteps.map((step, idx) => (
                <div
                  key={step.id}
                  onClick={() => toggleStep(step.id)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    step.done
                      ? 'bg-[#F2EBE3] border-[#DAC9BA] opacity-85'
                      : 'bg-white border-[#E7DCD0] hover:border-[#8E513D]/50 shadow-xs'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-7 h-7 rounded-full bg-[#EAE0D5] flex items-center justify-center text-xs font-bold text-[#6D5A4E] shrink-0 mt-0.5">
                      {idx + 1}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-[#8E513D] bg-[#F7EFE9] px-2 py-0.5 rounded">
                          {step.category}
                        </span>
                      </div>
                      <h4 className={`text-sm font-bold text-[#2A2622] mt-0.5 ${step.done ? 'line-through text-[#7E7369]' : ''}`}>
                        {step.name}
                      </h4>
                      <p className="text-xs text-[#70645B] mt-0.5">
                        {step.notes}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => removeStep(step.id, e)}
                      title="Remover produto"
                      className="text-[#B5A599] hover:text-[#D9534F] p-1 rounded transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <div
                      className={`w-7 h-7 rounded-full flex items-center justify-center transition-colors shrink-0 ${
                        step.done
                          ? 'bg-[#5B8C5A] text-white shadow-xs'
                          : 'border-2 border-[#C4B7AC] bg-white'
                      }`}
                    >
                      {step.done && <Check className="w-4 h-4 stroke-[3]" />}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Dica da Dra. Box */}
          <div className="bg-[#FAF3EB] rounded-2xl p-4 border border-[#E9DDD0] flex items-start gap-3">
            <div className="w-8 h-8 rounded-full bg-[#F2DCBE] flex items-center justify-center text-base shrink-0">
              🧴
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#985827]">
                Orientação Diária
              </span>
              <p className="text-xs text-[#544A41] mt-0.5 leading-relaxed">
                Nunca lave o rosto com água excessivamente quente no chuveiro. A água quente retira os lipídios naturais e aciona o reflexo de oleosidade rebote. Prefira água morna a fresca.
              </p>
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="bg-[#FAF7F2] px-6 py-4 border-t border-[#E8DFD5] flex justify-between items-center shrink-0">
          <span className="text-xs text-[#786D62]">
            Seus dados ficam salvos localmente no seu aparelho.
          </span>
          <button
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-[#2C2824] text-white text-xs font-bold hover:bg-black transition-colors cursor-pointer"
          >
            Fechar Aplicativo
          </button>
        </div>

      </div>
    </div>
  );
};
