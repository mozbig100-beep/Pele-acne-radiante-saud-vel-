import React from 'react';
import { Sparkles, ShieldCheck, Lock, Heart } from 'lucide-react';

interface FooterProps {
  onSelectProduct: (productId: 'ebook' | 'app' | 'bundle') => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectProduct }) => {
  return (
    <footer className="bg-[#24211D] text-[#C4B7AC] pt-16 pb-24 sm:pb-16 border-t border-[#38332E]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-12 border-b border-[#3B3530]">
          
          {/* Brand Info */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-[#EAD8CD] flex items-center justify-center text-[#7A4B3A]">
                <Sparkles className="w-4 h-4 text-[#8E513D]" />
              </div>
              <span className="font-serif-luxury text-xl font-bold text-white tracking-wide">
                Pele & Rotina
              </span>
            </div>
            <p className="text-xs sm:text-sm text-[#A89C92] leading-relaxed max-w-sm">
              Desenvolvido para descomplicar o cuidado com a pele acneica através de ciência, 
              simplicidade e consistência diária. Sem promessas falsas, apenas resultados reais.
            </p>
            <div className="flex items-center gap-4 text-xs text-[#8A7E74]">
              <span className="flex items-center gap-1">
                <Lock className="w-3.5 h-3.5 text-[#5B8C5A]" />
                Pagamento Seguro
              </span>
              <span>•</span>
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-[#5B8C5A]" />
                Garantia de 7 Dias
              </span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Nossos Produtos
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onSelectProduct('ebook')}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  E-book: Guia Prático (R$ 9,90)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectProduct('app')}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Aplicação: Minha Rotina (R$ 19,90)
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectProduct('bundle')}
                  className="hover:text-white transition-colors cursor-pointer text-left"
                >
                  Combo E-book + App (R$ 24,90)
                </button>
              </li>
            </ul>
          </div>

          {/* Support and Security */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Atendimento & Suporte
            </h4>
            <p className="text-xs text-[#A89C92] leading-relaxed">
              Dúvidas sobre seu pedido ou acesso aos materiais?
            </p>
            <div className="text-xs text-[#D9CBC0] font-mono">
              suporte@pelesemacne.com.br
            </div>
            <div className="text-[11px] text-[#7A6F65]">
              Horário de atendimento: Segunda a Sexta, das 09h às 18h.
            </div>
          </div>

        </div>

        {/* Disclaimer / Aviso Legal */}
        <div className="pt-8 text-[11px] text-[#786E65] leading-relaxed space-y-3">
          <p>
            <strong>Aviso Legal & Termos de Responsabilidade:</strong> As informações contidas neste site, no Guia Prático e no aplicativo "Minha Rotina" têm finalidade exclusivamente informativa e educacional sobre rotinas cosméticas e higiene da pele, não substituindo consultas, diagnósticos ou tratamentos médicos dermatológicos prescritos. Cada organismo reage de maneira única e os resultados podem variar de acordo com o tipo de pele e o grau de acometimento. Em casos de reações alérgicas ou infecções severas, consulte sempre um dermatologista.
          </p>
          <div className="flex flex-col sm:flex-row justify-between items-center gap-2 pt-4 border-t border-[#2F2A25]">
            <p>© {new Date().getFullYear()} Pele & Rotina. Todos os direitos reservados.</p>
            <p className="flex items-center gap-1">
              Feito com dedicação para a sua melhor pele
            </p>
          </div>
        </div>

      </div>
    </footer>
  );
};
