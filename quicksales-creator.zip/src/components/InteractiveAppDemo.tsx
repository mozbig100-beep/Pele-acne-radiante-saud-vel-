import React, { useState } from 'react';
import { 
  Check, 
  Sparkles, 
  Bell, 
  Calendar, 
  CheckCircle2, 
  ArrowRight, 
  Droplets, 
  Sun, 
  Moon, 
  ShieldCheck, 
  Flame, 
  ChevronRight,
  Home,
  Compass,
  User,
  ShoppingBag,
  RotateCcw
} from 'lucide-react';
import { calculateRoutineProgress } from '../utils/salesLogic';

interface InteractiveAppDemoProps {
  onSelectProduct: (productId: 'ebook' | 'app' | 'bundle') => void;
}

export const InteractiveAppDemo: React.FC<InteractiveAppDemoProps> = ({ onSelectProduct }) => {
  const [activeTab, setActiveTab] = useState<'today' | 'habits'>('today');
  const [timeOfDay, setTimeOfDay] = useState<'morning' | 'night'>('morning');
  
  // Interactive checklist state
  const [steps, setSteps] = useState([
    {
      id: 1,
      title: 'Limpeza',
      subtitle: 'Gel de limpeza suave',
      detail: 'Remove excesso de sebo sem agredir a barreira cutânea',
      done: true,
      time: 'morning'
    },
    {
      id: 2,
      title: 'Tônico facial',
      subtitle: 'Equilíbrio da pele',
      detail: 'Regula o pH e prepara os poros para o tratamento',
      done: true,
      time: 'morning'
    },
    {
      id: 3,
      title: 'Sérum Antiacne',
      subtitle: 'Ácido Salicílico 2% + Niacinamida',
      detail: 'Ação profunda anti-inflamatória e desobstrutora',
      done: false,
      time: 'morning'
    },
    {
      id: 4,
      title: 'Hidratação',
      subtitle: 'Gel creme oil-free com Cica',
      detail: 'Restaura a água celular sem obstruir os poros',
      done: false,
      time: 'morning'
    },
    {
      id: 5,
      title: 'Proteção Solar',
      subtitle: 'FPS 50 toque seco matte',
      detail: 'Evita que manchas pós-acne escureçam com a luz',
      done: false,
      time: 'morning'
    }
  ]);

  const toggleStep = (id: number) => {
    setSteps(prev =>
      prev.map(step => (step.id === id ? { ...step, done: !step.done } : step))
    );
  };

  const resetSteps = () => {
    setSteps(prev => prev.map((s, idx) => ({ ...s, done: idx < 2 })));
  };

  const progress = calculateRoutineProgress(steps.map(s => s.done));

  // Calendar days representation (June 2025 as in reference image)
  const calendarDays = [
    { day: 'S', date: 8, completed: true },
    { day: 'T', date: 9, completed: true },
    { day: 'Q', date: 10, completed: true },
    { day: 'Q', date: 11, completed: true, active: true },
    { day: 'S', date: 12, completed: false },
    { day: 'S', date: 13, completed: false },
    { day: 'D', date: 14, completed: false },
  ];

  return (
    <section id="demo-app" className="py-16 sm:py-24 bg-[#F5EFEB] border-y border-[#E6DDD3]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E8DDD2] text-[#8E513D] text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Demonstração Interativa em Tempo Real</span>
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2C2925]">
            Experimente o Aplicativo <br className="hidden sm:block" />
            <span className="italic font-normal text-[#8E513D]">Minha Rotina Skincare</span>
          </h2>
          <p className="text-sm sm:text-base text-[#675C53] mt-3">
            Toque nos passos abaixo para marcar como concluído e veja como o aplicativo acompanha seu progresso, hábitos e rotinas diárias.
          </p>
        </div>

        {/* Two-Column Showcase: Interactive Phone on Left/Center, Benefits on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 sm:gap-12 items-center max-w-5xl mx-auto">
          
          {/* Interactive Phone Frame (Matching user mockup) */}
          <div className="lg:col-span-7 flex justify-center">
            <div className="w-full max-w-[360px] sm:max-w-[390px] bg-[#121212] rounded-[44px] p-3 sm:p-4 shadow-2xl border-4 border-[#2A2724] ring-1 ring-black/50 relative">
              {/* Speaker / Dynamic Island */}
              <div className="absolute top-6 left-1/2 -translate-x-1/2 w-28 h-5 bg-black rounded-full z-30 flex items-center justify-end pr-2">
                <div className="w-2.5 h-2.5 rounded-full bg-[#1A1A1A] border border-[#333]"></div>
              </div>

              {/* App Screen Interior */}
              <div className="bg-[#FAF7F2] rounded-[34px] overflow-hidden text-[#2C2925] flex flex-col h-[670px] relative font-sans">
                
                {/* Status Bar */}
                <div className="pt-3 px-6 pb-2 flex justify-between items-center text-xs font-semibold text-[#443F3A] shrink-0">
                  <span>9:41</span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-bold">5G</span>
                    <div className="w-5 h-2.5 border border-[#443F3A] rounded-sm p-0.5 flex items-center">
                      <div className="h-full bg-[#443F3A] w-3/4 rounded-2xs"></div>
                    </div>
                  </div>
                </div>

                {/* App Header */}
                <div className="px-5 pt-2 pb-3 shrink-0 flex justify-between items-center border-b border-[#EDE4DB]">
                  <div>
                    <h3 className="font-serif-luxury text-xl font-bold text-[#2A2622] leading-tight">
                      Minha rotina
                    </h3>
                    <p className="text-xs text-[#7A6F66]">
                      Olá, Camila! 👋
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button 
                      onClick={resetSteps}
                      title="Reiniciar demonstração"
                      className="p-1.5 rounded-full text-[#8C7E74] hover:bg-[#EFE5DC] transition-colors"
                    >
                      <RotateCcw className="w-4 h-4" />
                    </button>
                    <div className="w-8 h-8 rounded-full bg-[#EFE5DC] flex items-center justify-center text-[#8E513D] relative">
                      <Bell className="w-4 h-4" />
                      <span className="absolute top-1 right-1 w-2 h-2 bg-[#D9534F] rounded-full"></span>
                    </div>
                  </div>
                </div>

                {/* Scrollable Content inside Phone */}
                <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
                  
                  {/* Progress Card (as in mockup) */}
                  <div className="bg-[#FFFFFF] rounded-2xl p-4 border border-[#E9DFD5] shadow-xs">
                    <div className="flex justify-between items-center mb-1.5">
                      <span className="text-xs font-bold text-[#443D36] uppercase tracking-wide">
                        Progresso de Hoje
                      </span>
                      <span className="text-xs font-extrabold text-[#8E513D] font-mono">
                        {progress}%
                      </span>
                    </div>

                    <div className="w-full bg-[#EFE8E1] h-2.5 rounded-full overflow-hidden">
                      <div 
                        className="bg-gradient-to-r from-[#C68B70] to-[#8E513D] h-full rounded-full transition-all duration-500 ease-out"
                        style={{ width: `${progress}%` }}
                      />
                    </div>

                    <p className="text-[11px] text-[#7A6F65] mt-2 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-[#C68B70]" />
                      {progress === 100 
                        ? '🎉 Parabéns! Rotina completa finalizada com sucesso!' 
                        : progress >= 60 
                        ? 'Muito bom! Continue assim com sua rotina.' 
                        : 'Dê o primeiro passo para o cuidado da sua pele hoje.'}
                    </p>
                  </div>

                  {/* Tabs: Rotina de Hoje vs Meus Hábitos */}
                  <div className="flex bg-[#EFE7DE] p-1 rounded-xl text-xs font-semibold">
                    <button
                      onClick={() => setActiveTab('today')}
                      className={`flex-1 py-1.5 rounded-lg transition-all text-center ${
                        activeTab === 'today'
                          ? 'bg-white text-[#2C2925] shadow-xs'
                          : 'text-[#7A6E64] hover:text-[#2C2925]'
                      }`}
                    >
                      Rotina de Hoje
                    </button>
                    <button
                      onClick={() => setActiveTab('habits')}
                      className={`flex-1 py-1.5 rounded-lg transition-all text-center ${
                        activeTab === 'habits'
                          ? 'bg-white text-[#2C2925] shadow-xs'
                          : 'text-[#7A6E64] hover:text-[#2C2925]'
                      }`}
                    >
                      Meus Hábitos
                    </button>
                  </div>

                  {/* Tab 1: Rotina de Hoje */}
                  {activeTab === 'today' && (
                    <div className="space-y-2.5">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-bold text-[#554C44] uppercase tracking-wider">
                          Passo a Passo
                        </span>
                        <div className="flex items-center gap-1 bg-[#EBE1D7] px-2 py-0.5 rounded-md text-[10px] font-semibold text-[#6C5F54]">
                          <Sun className="w-3 h-3 text-[#D98E32]" />
                          <span>Rotina Diurna</span>
                        </div>
                      </div>

                      {steps.map((step) => (
                        <div
                          key={step.id}
                          onClick={() => toggleStep(step.id)}
                          className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                            step.done 
                              ? 'bg-[#F2ECE4] border-[#D8C7B9] opacity-90' 
                              : 'bg-white border-[#E9DFD5] hover:border-[#8E513D]/60 shadow-2xs'
                          }`}
                        >
                          <div className="flex items-start gap-2.5">
                            <div className="mt-0.5 w-6 h-6 rounded-full bg-[#EAE0D5] flex items-center justify-center text-[11px] font-bold text-[#6D5A4E] shrink-0">
                              {step.id}
                            </div>
                            <div>
                              <h4 className={`text-xs font-bold text-[#2E2925] ${step.done ? 'line-through text-[#7A6F65]' : ''}`}>
                                {step.title}
                              </h4>
                              <p className="text-[11px] text-[#695F57] font-medium leading-tight">
                                {step.subtitle}
                              </p>
                            </div>
                          </div>

                          {/* Checkbox circle matching reference */}
                          <div 
                            className={`w-6 h-6 rounded-full flex items-center justify-center transition-colors shrink-0 ${
                              step.done 
                                ? 'bg-[#5B8C5A] text-white shadow-xs' 
                                : 'border-2 border-[#C4B7AC] bg-white'
                            }`}
                          >
                            {step.done && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                          </div>
                        </div>
                      ))}

                      {/* Dica do Dia Box (as seen in the mockup) */}
                      <div className="bg-[#F9F3EC] border border-[#E7DCD1] rounded-xl p-3 flex items-start gap-2.5">
                        <div className="w-6 h-6 rounded-full bg-[#F3DEC9] flex items-center justify-center text-[#B56728] shrink-0 mt-0.5">
                          💡
                        </div>
                        <div>
                          <span className="text-[10px] font-bold uppercase tracking-wider text-[#985827] block">
                            Dica do Dia
                          </span>
                          <p className="text-xs text-[#524840] leading-snug">
                            Evite espremer espinhas para não romper a barreira da derme e prevenir cicatrizes permanentes.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Tab 2: Meus Hábitos (Calendar & Consistency) */}
                  {activeTab === 'habits' && (
                    <div className="space-y-3">
                      <div className="bg-white rounded-xl p-3 border border-[#E9DFD5]">
                        <div className="flex justify-between items-center text-xs font-bold text-[#443D36] mb-3">
                          <span>Junho 2025</span>
                          <span className="text-[#8E513D] flex items-center gap-1 text-[11px]">
                            <Flame className="w-3.5 h-3.5 text-[#E06D53]" />
                            4 dias seguidos
                          </span>
                        </div>
                        <div className="grid grid-cols-7 gap-1 text-center">
                          {calendarDays.map((item, idx) => (
                            <div key={idx} className="flex flex-col items-center">
                              <span className="text-[10px] font-medium text-[#8F8277]">{item.day}</span>
                              <div
                                className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold mt-1 ${
                                  item.active
                                    ? 'bg-[#8E513D] text-white shadow-xs'
                                    : item.completed
                                    ? 'bg-[#E4ECE3] text-[#407A3F]'
                                    : 'text-[#968A80]'
                                }`}
                              >
                                {item.date}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="bg-[#FAF3EB] rounded-xl p-3 border border-[#E9DFD5] space-y-2">
                        <span className="text-xs font-bold text-[#443D36] block">
                          Ativos em Uso:
                        </span>
                        <div className="space-y-1.5 text-xs text-[#5C5248]">
                          <div className="flex justify-between items-center bg-white p-2 rounded-lg border border-[#EDE2D7]">
                            <span>🌿 Centella Asiatica (Cica)</span>
                            <span className="text-[10px] bg-[#E8F0E8] text-[#3D773C] px-1.5 py-0.5 rounded font-semibold">Ativo</span>
                          </div>
                          <div className="flex justify-between items-center bg-white p-2 rounded-lg border border-[#EDE2D7]">
                            <span>🧪 Niacinamida 5%</span>
                            <span className="text-[10px] bg-[#E8F0E8] text-[#3D773C] px-1.5 py-0.5 rounded font-semibold">Ativo</span>
                          </div>
                          <div className="flex justify-between items-center bg-white p-2 rounded-lg border border-[#EDE2D7]">
                            <span>💧 Ácido Salicílico 2%</span>
                            <span className="text-[10px] bg-[#E8F0E8] text-[#3D773C] px-1.5 py-0.5 rounded font-semibold">Ativo</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                </div>

                {/* Bottom App Navigation Bar (as in mockup) */}
                <div className="bg-white border-t border-[#E8DFD5] px-4 py-2.5 flex justify-around items-center text-[10px] font-semibold text-[#8C7F74] shrink-0">
                  <div className="flex flex-col items-center gap-0.5 text-[#8E513D]">
                    <Home className="w-4 h-4" />
                    <span>Início</span>
                  </div>
                  <div className="flex flex-col items-center gap-0.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Rotina</span>
                  </div>
                  <div className="flex flex-col items-center gap-0.5">
                    <Compass className="w-4 h-4" />
                    <span>Descobrir</span>
                  </div>
                  <div className="flex flex-col items-center gap-0.5">
                    <User className="w-4 h-4" />
                    <span>Perfil</span>
                  </div>
                </div>

              </div>
            </div>
          </div>

          {/* Interactive Feature Explanations & CTA on Right */}
          <div className="lg:col-span-5 space-y-6">
            <div className="space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-[#8E513D]">
                A revolução no seu autocuidado
              </span>
              <h3 className="font-serif-luxury text-2xl sm:text-3xl font-bold text-[#2A2622]">
                A consistência diária é 80% do sucesso contra a acne.
              </h3>
              <p className="text-sm text-[#5F554C] leading-relaxed">
                Você não precisa de tratamentos agressivos ou caros. O segredo está em 
                seguir a sequência certa de ativos todos os dias, sem esquecer nem pular etapas.
              </p>
            </div>

            <div className="space-y-3.5">
              <div className="flex items-start gap-3 bg-white p-3.5 rounded-2xl border border-[#E9DFD5] shadow-xs">
                <div className="w-8 h-8 rounded-xl bg-[#F0E5DC] flex items-center justify-center text-[#8E513D] shrink-0 font-bold text-sm">
                  1
                </div>
                <div>
                  <h4 className="text-sm font-bold text-[#2D2A26]">Checklist Diário com Lembretes</h4>
                  <p className="text-xs text-[#6C6157] mt-0.5">
                    Marque cada etapa em segundos pela manhã e noite. Nunca mais fique em dúvida se já passou o sérum ou hidratante.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-white p-3.5 rounded-2xl border border-[#E9DFD5] shadow-xs">
                <div className="w-8 h-8 rounded-xl bg-[#F0E5DC] flex items-center justify-center text-[#8E513D] shrink-0 font-bold text-sm">
                  2
                </div>
                <div>
                  <h4 className="text-sm font-bold text-[#2D2A26]">Rastreador de Hábitos & Progresso</h4>
                  <p className="text-xs text-[#6C6157] mt-0.5">
                    Veja visualmente suas semanas de consistência (70%, 90%, 100%) e acompanhe o clareamento da pele com o tempo.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 bg-white p-3.5 rounded-2xl border border-[#E9DFD5] shadow-xs">
                <div className="w-8 h-8 rounded-xl bg-[#F0E5DC] flex items-center justify-center text-[#8E513D] shrink-0 font-bold text-sm">
                  3
                </div>
                <div>
                  <h4 className="text-sm font-bold text-[#2D2A26]">Compatível com Qualquer Dispositivo</h4>
                  <p className="text-xs text-[#6C6157] mt-0.5">
                    Funciona direto no navegador do iPhone, Android, tablet ou computador. Sem ocupar espaço de memória!
                  </p>
                </div>
              </div>
            </div>

            {/* Price Box & CTA */}
            <div className="bg-[#FAF7F2] border-2 border-[#8E513D] rounded-2xl p-5 shadow-md space-y-3">
              <div className="flex justify-between items-center">
                <div>
                  <span className="text-xs text-[#8C7F74] line-through block">De R$ 97,00</span>
                  <div className="text-2xl sm:text-3xl font-extrabold text-[#8E513D] font-mono">
                    R$ 19,90
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[11px] bg-[#E8F0E8] text-[#2F6F30] px-2 py-0.5 rounded font-bold uppercase tracking-wider block">
                    Acesso Imediato
                  </span>
                  <span className="text-[11px] text-[#7A6F64]">Sem mensalidades</span>
                </div>
              </div>

              <button
                onClick={() => onSelectProduct('app')}
                className="w-full bg-[#8E513D] hover:bg-[#794231] text-white py-3.5 px-4 rounded-xl font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Quero o Aplicativo por R$ 19,90</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
