import React from 'react';
import { Droplets, Sparkles, Shield, HeartPulse, CheckCircle2 } from 'lucide-react';

export const ScienceSection: React.FC = () => {
  const actives = [
    {
      name: 'Centella Asiatica (Cica)',
      badge: 'Calmante & Reparador',
      role: 'Regeneração da Barreira Cutânea',
      desc: 'Extrato vegetal potente rico em madecassoside. Acalma a vermelhidão inflamatória em minutos, acelera a cicatrização das lesões e evita manchas escuras pós-acne.',
      icon: '🌿'
    },
    {
      name: 'Niacinamida (Vitamina B3)',
      badge: 'Regulador de Sebo',
      role: 'Controle de Oleosidade & Poros',
      desc: 'Regula a produção excessiva das glândulas sebáceas sem ressecar a derme. Uniformiza o tom da pele, suaviza a textura irregular e fortalece a barreira de hidratação.',
      icon: '🧪'
    },
    {
      name: 'Ácido Salicílico 2%',
      badge: 'Ação Desobstrutora',
      role: 'Eliminação de Cravos & Poros Limpos',
      desc: 'O único beta-hidroxiácido lipossolúvel capaz de penetrar profundamente dentro do folículo e dissolver o tampão de gordura e células mortas antes de virar espinha.',
      icon: '💧'
    }
  ];

  return (
    <section className="py-16 sm:py-24 bg-[#FAF7F2] border-t border-[#EDE4DB]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        
        {/* Title */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#E8DDD2] text-[#8E513D] text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Base Dermatológica Comprovada</span>
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2A2622]">
            O Trio de Ouro: Por Que Este Método Funciona?
          </h2>
          <p className="text-sm sm:text-base text-[#655B51] mt-3">
            Em vez de dezenas de cosméticos que pesam no bolso e irritam o rosto, focamos no que a ciência comprovou ser eficaz contra a acne.
          </p>
        </div>

        {/* 3 Actives Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {actives.map((item, idx) => (
            <div 
              key={idx}
              className="bg-white rounded-3xl p-6 sm:p-7 border border-[#E5DACF] shadow-xs hover:shadow-md transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-[#FAF3EC] border border-[#EBDDD0] flex items-center justify-center text-2xl mb-4">
                  {item.icon}
                </div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#8E513D] block">
                  {item.badge}
                </span>
                <h3 className="font-serif-luxury text-xl font-bold text-[#2A2622] mt-1">
                  {item.name}
                </h3>
                <p className="text-xs font-semibold text-[#547953] mt-1 mb-3">
                  {item.role}
                </p>
                <p className="text-xs text-[#635950] leading-relaxed">
                  {item.desc}
                </p>
              </div>

              <div className="mt-5 pt-4 border-t border-[#F2ECE5] flex items-center gap-2 text-xs text-[#4F463E] font-medium">
                <CheckCircle2 className="w-4 h-4 text-[#5B8C5A] shrink-0" />
                <span>Sem ressecamento ou efeito rebote</span>
              </div>
            </div>
          ))}
        </div>

        {/* Dermatologist note box */}
        <div className="mt-10 max-w-4xl mx-auto bg-[#F4ECE3] rounded-2xl p-5 sm:p-6 border border-[#E2D5C7] flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left">
          <div className="w-12 h-12 rounded-full bg-[#E6D7C8] flex items-center justify-center text-[#7F4E3E] shrink-0 font-bold text-xl">
            🩺
          </div>
          <div>
            <h4 className="text-sm font-bold text-[#2A2622]">
              Princípio da Barreira Cutânea Respeitada
            </h4>
            <p className="text-xs sm:text-sm text-[#5E544A] mt-0.5">
              Tanto o livro quanto o app foram estruturados para <strong>nunca agredir</strong> o manto hidrolipídico. 
              Tratamos a acne reduzindo a bactéria <em>C. acnes</em> e a inflamação, mantendo sua pele hidratada, viçosa e saudável.
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
