import React from 'react';
import { Check, Sparkles, BookOpen, Smartphone, Zap, ArrowRight, ShieldCheck } from 'lucide-react';
import { PRODUCTS, formatCurrencyBRL } from '../utils/salesLogic';

interface ProductComparisonProps {
  onSelectProduct: (productId: 'ebook' | 'app' | 'bundle') => void;
}

export const ProductComparison: React.FC<ProductComparisonProps> = ({ onSelectProduct }) => {
  return (
    <section id="produtos" className="py-16 sm:py-24 bg-[#FAF7F2]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EAD8CD] text-[#7A4B3A] text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Escolha o Formato Perfeito Para Você</span>
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2A2622]">
            Planos Transparentes e Sem Mensalidades
          </h2>
          <p className="text-sm sm:text-base text-[#655B51] mt-3">
            Comece hoje mesmo a cuidar da sua pele pelo menor preço do mercado. Pagamento único com acesso vitalício.
          </p>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch max-w-5xl mx-auto">
          
          {/* Card 1: E-book */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-[#E2D5C8] shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-[#EFE8E1] flex items-center justify-center text-[#6E5A4E]">
                  <BookOpen className="w-4 h-4" />
                </div>
                <span className="text-xs font-bold uppercase tracking-wider text-[#796A5E]">
                  Formato Livro Digital
                </span>
              </div>

              <h3 className="font-serif-luxury text-2xl font-bold text-[#2A2622]">
                Guia Prático
              </h3>
              <p className="text-xs text-[#73685F] mt-1">
                Cuidados com a Pele Acne em PDF para ler no celular, computador ou imprimir.
              </p>

              <div className="mt-5 pb-5 border-b border-[#EFE5DC]">
                <span className="text-xs text-[#9E9085] line-through block">De R$ 47,00</span>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="text-3xl font-extrabold text-[#2A2622] font-mono">
                    R$ 9,90
                  </span>
                  <span className="text-xs text-[#7A6F66]">à vista</span>
                </div>
                <span className="inline-block mt-2 text-[11px] font-bold text-[#2E7D32] bg-[#E8F0E8] px-2 py-0.5 rounded">
                  Economia de 79%
                </span>
              </div>

              <div className="py-5 space-y-3">
                <span className="text-xs font-bold text-[#473F38] uppercase tracking-wider block">
                  O que está incluso:
                </span>
                <ul className="space-y-2.5 text-xs text-[#584D44]">
                  {PRODUCTS.ebook.features.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-[#5B8C5A] shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="pt-4">
              <button
                onClick={() => onSelectProduct('ebook')}
                className="w-full py-3.5 px-4 rounded-xl font-bold text-sm bg-[#3D3731] hover:bg-[#25211D] text-white shadow-sm hover:shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Comprar E-book por R$ 9,90</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <p className="text-center text-[10px] text-[#9A8D82] mt-2">
                Download imediato no e-mail e WhatsApp
              </p>
            </div>
          </div>

          {/* Card 2: Aplicação (Highlight / Best Seller) */}
          <div className="relative bg-[#FFFFFF] rounded-3xl p-6 sm:p-7 border-2 border-[#8E513D] shadow-xl hover:shadow-2xl transition-all duration-300 flex flex-col justify-between ring-4 ring-[#8E513D]/10 transform md:-translate-y-2">
            <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-[#8E513D] text-white text-[11px] font-bold px-3.5 py-1 rounded-full uppercase tracking-wider flex items-center gap-1 shadow-sm whitespace-nowrap">
              <Sparkles className="w-3.5 h-3.5 text-[#FFD166]" />
              Mais Popular • Recomendado
            </div>

            <div>
              <div className="flex items-center gap-2 mb-3 mt-1">
                <div className="w-8 h-8 rounded-lg bg-[#F5E6DC] flex items-center justify-center text-[#8E513D]">
                  <Smartphone className="w-4 h-4" />
                </div>
                <span className="text-xs font-bold uppercase tracking-wider text-[#8E513D]">
                  Aplicação Web Interativa
                </span>
              </div>

              <h3 className="font-serif-luxury text-2xl font-bold text-[#2A2622]">
                Minha Rotina Skincare
              </h3>
              <p className="text-xs text-[#73685F] mt-1">
                Aplicativo inteligente para registrar hábitos diários, produtos e métricas.
              </p>

              <div className="mt-5 pb-5 border-b border-[#EFE5DC]">
                <span className="text-xs text-[#9E9085] line-through block">De R$ 97,00</span>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="text-3xl font-extrabold text-[#8E513D] font-mono">
                    R$ 19,90
                  </span>
                  <span className="text-xs text-[#7A6F66]">à vista</span>
                </div>
                <span className="inline-block mt-2 text-[11px] font-bold text-[#2E7D32] bg-[#E8F0E8] px-2 py-0.5 rounded">
                  Acesso Vitalício sem Mensalidade
                </span>
              </div>

              <div className="py-5 space-y-3">
                <span className="text-xs font-bold text-[#473F38] uppercase tracking-wider block">
                  Tudo o que o App oferece:
                </span>
                <ul className="space-y-2.5 text-xs text-[#584D44]">
                  {PRODUCTS.app.features.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-[#8E513D] shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="pt-4">
              <button
                onClick={() => onSelectProduct('app')}
                className="w-full py-3.5 px-4 rounded-xl font-bold text-sm bg-[#8E513D] hover:bg-[#794231] text-white shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Acessar o App por R$ 19,90</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <p className="text-center text-[10px] text-[#9A8D82] mt-2">
                Acesse em qualquer celular, tablet ou PC
              </p>
            </div>
          </div>

          {/* Card 3: Combo Bundle (Best value) */}
          <div className="bg-[#FAF2EB] rounded-3xl p-6 sm:p-7 border border-[#DFCBB9] shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-[#E8D4C3] flex items-center justify-center text-[#784635]">
                  <Zap className="w-4 h-4" />
                </div>
                <span className="text-xs font-bold uppercase tracking-wider text-[#784635]">
                  Pacote Completo VIP
                </span>
              </div>

              <h3 className="font-serif-luxury text-2xl font-bold text-[#2A2622]">
                E-book + Aplicativo
              </h3>
              <p className="text-xs text-[#73685F] mt-1">
                Tenha o conhecimento científico profundo somado à aplicação diária.
              </p>

              <div className="mt-5 pb-5 border-b border-[#E3D2C4]">
                <span className="text-xs text-[#9E9085] line-through block">De R$ 144,00</span>
                <div className="flex items-baseline gap-1 mt-0.5">
                  <span className="text-3xl font-extrabold text-[#784635] font-mono">
                    R$ 24,90
                  </span>
                  <span className="text-xs text-[#7A6F66]">à vista</span>
                </div>
                <span className="inline-block mt-2 text-[11px] font-bold text-[#2E7D32] bg-[#E8F0E8] px-2 py-0.5 rounded">
                  Economize 83% no Combo
                </span>
              </div>

              <div className="py-5 space-y-3">
                <span className="text-xs font-bold text-[#473F38] uppercase tracking-wider block">
                  Benefícios Exclusivos:
                </span>
                <ul className="space-y-2.5 text-xs text-[#584D44]">
                  {PRODUCTS.bundle.features.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2.5">
                      <Check className="w-4 h-4 text-[#5B8C5A] shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="pt-4">
              <button
                onClick={() => onSelectProduct('bundle')}
                className="w-full py-3.5 px-4 rounded-xl font-bold text-sm bg-[#784635] hover:bg-[#613627] text-white shadow-sm hover:shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Garantir Combo por R$ 24,90</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <p className="text-center text-[10px] text-[#9A8D82] mt-2">
                Leve ambos com desconto máximo
              </p>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
