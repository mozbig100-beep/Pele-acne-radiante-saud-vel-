import React from 'react';
import { Star, CheckCircle, Quote, Sparkles } from 'lucide-react';

export const Testimonials: React.FC = () => {
  const testimonials = [
    {
      name: 'Camila Rodrigues',
      city: 'Belo Horizonte, MG',
      product: 'Usou: App + E-book',
      time: '3 semanas de uso',
      text: 'Eu gastava mais de 300 reais por mês em produtos aleatórios que só pioravam minhas espinhas. Com o checklist do app, consegui ter constância pela primeira vez na vida! Minha pele desinflamou e os cravos sumiram quase todos.',
      rating: 5,
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&h=150&q=80'
    },
    {
      name: 'Mariana Silveira',
      city: 'São Paulo, SP',
      product: 'Usou: E-book Cuidados com a Pele Acne',
      time: '18 dias de rotina',
      text: 'O e-book vale 10 vezes mais que os R$ 9,90. A lista de produtos de farmácia baratinhos me economizou muito dinheiro. A explicação sobre como usar a Cica e a Niacinamida mudou o jogo pra mim.',
      rating: 5,
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&h=150&q=80'
    },
    {
      name: 'Lucas Mendes',
      city: 'Curitiba, PR',
      product: 'Usou: Aplicativo Minha Rotina',
      time: '1 mês de uso',
      text: 'Como homem, eu sempre achei skincare confuso. O aplicativo é muito simples e direto: abre, marca os passos da manhã e da noite e pronto. Minha oleosidade no meio do dia diminuiu uns 80%.',
      rating: 5,
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150&q=80'
    },
    {
      name: 'Beatriz Almeida',
      city: 'Rio de Janeiro, RJ',
      product: 'Usou: Combo E-book + App',
      time: '4 semanas de uso',
      text: 'Já tinha tentado de tudo, até ácidos que descamavam meu rosto inteiro e doíam. O método de cuidado gentil com a barreira cutânea foi a única coisa que realmente curou a vermelhidão. Recomendo muito!',
      rating: 5,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80'
    }
  ];

  return (
    <section id="depoimentos" className="py-16 sm:py-24 bg-[#F5EFEB] border-t border-[#E8DDD2]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#EAD8CD] text-[#7A4B3A] text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Resultados Reais de Pessoas Reais</span>
          </div>
          <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-[#2A2622]">
            Mais de 4.800 Pessoas Transformaram a Saúde da Pele
          </h2>
          <p className="text-sm sm:text-base text-[#655B51] mt-3">
            Veja o que diz quem já colocou o guia e o aplicativo em prática no dia a dia.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
          {testimonials.map((t, idx) => (
            <div 
              key={idx}
              className="bg-white rounded-3xl p-6 sm:p-7 border border-[#E3D6C9] shadow-xs flex flex-col justify-between"
            >
              <div>
                {/* Rating stars */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex text-[#DF9B2A]">
                    {[...Array(t.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-current" />
                    ))}
                  </div>
                  <span className="text-[11px] font-semibold text-[#8E513D] bg-[#F8ECE3] px-2 py-0.5 rounded-full">
                    {t.time}
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-[#4E443B] leading-relaxed italic mb-5">
                  "{t.text}"
                </p>
              </div>

              {/* User info */}
              <div className="pt-4 border-t border-[#F2ECE5] flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img 
                    src={t.avatar} 
                    alt={t.name}
                    className="w-10 h-10 rounded-full object-cover border border-[#DFD1C4]" 
                  />
                  <div>
                    <h4 className="text-xs sm:text-sm font-bold text-[#2A2622] flex items-center gap-1">
                      {t.name}
                      <CheckCircle className="w-3.5 h-3.5 text-[#5B8C5A]" />
                    </h4>
                    <span className="text-[11px] text-[#7E7166]">{t.city}</span>
                  </div>
                </div>

                <span className="text-[10px] text-[#7A6D63] font-medium hidden sm:inline-block">
                  {t.product}
                </span>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
